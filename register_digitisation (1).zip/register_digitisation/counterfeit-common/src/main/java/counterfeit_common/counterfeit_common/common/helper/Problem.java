package counterfeit_common.counterfeit_common.common.helper;

public class Problem {
    private final String code;
    private final String message;

    // Private constructor to enforce the use of the builder
    private Problem(String code, String message) {
        this.code = code;
        this.message = message;
    }

    // Getters
    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    // Static method to get a new Builder instance
    public static Builder builder() {
        return new Builder();
    }

    // Builder class
    public static class Builder {
        private String code;
        private String message;

        // Setter for code
        public Builder code(String code) {
            this.code = code;
            return this;
        }

        // Setter for message
        public Builder message(String message) {
            this.message = message;
            return this;
        }

        // Build method to create a Problem instance
        public Problem build() {
            if (code == null || message == null) {
                throw new IllegalArgumentException("Both code and message must be provided");
            }
            return new Problem(code, message);
        }
    }
}