package counterfeit_common.counterfeit_common.common.exceptions;

public class ApprovalRequiredFieldsException extends RuntimeException {
    public ApprovalRequiredFieldsException(String message) {
        super(message);
    }

    public ApprovalRequiredFieldsException(String message, Throwable cause) {
        super(message, cause);
    }
}