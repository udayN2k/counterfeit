package counterfeit_common.counterfeit_common.common.exceptions;

public class WorkflowUpdateException extends RuntimeException {
    public WorkflowUpdateException(String message) {
        super(message);
    }

    public WorkflowUpdateException(String message, Throwable cause) {
        super(message, cause);
    }

    public WorkflowUpdateException(Throwable cause) {
        super(cause);
    }
}