package counterfeit_common.counterfeit_common.common.exceptions;

public class TransactionFilterException extends RuntimeException {
    public TransactionFilterException(String message) {
        super(message);
    }

    public TransactionFilterException(String message, Throwable cause) {
        super(message, cause);
    }
}