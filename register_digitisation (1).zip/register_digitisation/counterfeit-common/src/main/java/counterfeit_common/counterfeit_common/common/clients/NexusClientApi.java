package counterfeit_common.counterfeit_common.common.clients;

import feign.RequestLine;
import feign.Headers;
import feign.Param;
import org.springframework.stereotype.Component;

@Component
public interface NexusClientApi {

    @RequestLine("GET /reports/{reportId}")
    @Headers("Authorization: Bearer {authToken}")
    String fetchReportDetails(@Param("reportId") String reportId, @Param("authToken") String authToken);

}
