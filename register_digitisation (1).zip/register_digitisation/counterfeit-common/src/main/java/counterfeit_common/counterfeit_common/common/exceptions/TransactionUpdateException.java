package counterfeit_common.counterfeit_common.common.exceptions;

public class TransactionUpdateException extends Exception {

    public TransactionUpdateException(String message) {
        super(message);
    }

    public TransactionUpdateException(String message, Throwable cause) {
        super(message, cause);
    }
}
