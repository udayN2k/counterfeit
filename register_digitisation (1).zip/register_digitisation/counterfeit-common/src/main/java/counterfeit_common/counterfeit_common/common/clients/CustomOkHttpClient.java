package counterfeit_common.counterfeit_common.common.clients;

import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import okhttp3.OkHttpClient;
import org.springframework.stereotype.Component;
import counterfeit_common.counterfeit_common.common.exceptions.ManagedException;

@Component
public class CustomOkHttpClient {

  X509TrustManager trustManager =
      new X509TrustManager() {
        public X509Certificate[] getAcceptedIssuers() {
          return new X509Certificate[0];
        }

        public void checkClientTrusted(X509Certificate[] certs, String authType) {}

        public void checkServerTrusted(X509Certificate[] certs, String authType) {}
      };

  public OkHttpClient getClient() {
    SSLContext sslContext;
    try {
      sslContext = SSLContext.getInstance("TLS");
      sslContext.init(null, new X509TrustManager[] {trustManager}, new SecureRandom());
    } catch (Exception exception) {
      throw ManagedException.builder()
          .rawException(exception)
          .message("An error occurred during SSLContext initialization")
          .build();
    }

    return new OkHttpClient.Builder()
        .sslSocketFactory(sslContext.getSocketFactory(), trustManager)
        .hostnameVerifier((hostname, session) -> true)
        .build();
  }
}
