package counterfeit_common.counterfeit_common.common.helper;

import counterfeit_common.counterfeit_common.datasource.entities.FIREntity;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionEntity;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionReportingEntity;
import counterfeit_common.counterfeit_common.datasource.impl.DbFirDao;
import counterfeit_common.counterfeit_common.datasource.impl.DynamoDbCounterfeitDao;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class CounterfeitDbHelper {

    private final DynamoDbCounterfeitDao dynamoDbCounterfeitDao;
    private final DbFirDao dbFirDao;

    @Autowired
    public CounterfeitDbHelper(DynamoDbCounterfeitDao dynamoDbCounterfeitDao,DbFirDao dbFirDao) {
        this.dynamoDbCounterfeitDao = dynamoDbCounterfeitDao;
        this.dbFirDao=dbFirDao;
    }

    public TransactionEntity getTransactionById(String transactionId, Integer version) {
        return dynamoDbCounterfeitDao.getTransactionById(transactionId, version);
    }

    public TransactionReportingEntity getTransactionReportingById(String transactionId) {
        return dynamoDbCounterfeitDao.getTransactionReportingById(transactionId);
    }

    public List<TransactionEntity> getAllTransactions() {
        return dynamoDbCounterfeitDao.getAllTransactions();
    }

    public void saveTransaction(TransactionEntity transactions) {
        dynamoDbCounterfeitDao.saveTransaction(transactions);
    }

    public void saveTransactionReporting(TransactionReportingEntity transactionReportingEntity) {
        dynamoDbCounterfeitDao.saveTransactionReporting(transactionReportingEntity);
    }

    public void updateTransaction(TransactionEntity transaction) {

        dynamoDbCounterfeitDao.updateTransaction(transaction);
    }

    public void saveFir(FIREntity fir) {

        dbFirDao.saveFir(fir);
    }

    public FIREntity getFIRById(String firReportId,String branchCode) {
        return dbFirDao.findFIRByHashKey(firReportId,branchCode);
    }

    public List<FIREntity> findByBranchCode(String branchCode) {
        return dbFirDao.findByBranchCode(branchCode);
    }

    public List<FIREntity> getAllFIR() {
        return dbFirDao.getAllFIR();
    }


}