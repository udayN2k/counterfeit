package counterfeit_common.counterfeit_common.datasource.impl;

import counterfeit_common.counterfeit_common.common.exceptions.TransactionNotFoundException;
import counterfeit_common.counterfeit_common.datasource.clients.CounterfeitDynamoDbClient;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionEntity;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionReportingEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DynamoDbCounterfeitDao implements CounterfeitDao {

    private final CounterfeitDynamoDbClient dynamoDbClient;

    @Autowired
    public DynamoDbCounterfeitDao(CounterfeitDynamoDbClient dynamoDBClient) {
        this.dynamoDbClient = dynamoDBClient;
    }

    @Override
    public TransactionEntity getTransactionById(String recordId, Integer version) {
        TransactionEntity response = dynamoDbClient.findTransactionByHashKey(recordId, version);
        if (response == null) {
            throw new TransactionNotFoundException("Transaction not found for id: " + recordId);
        }
        return response;
    }

    @Override
    public TransactionReportingEntity getTransactionReportingById(String transactionId) {
        TransactionReportingEntity response = dynamoDbClient.findTransactionReportingByHashKey(transactionId);
        if (response == null) {
            throw new TransactionNotFoundException("Transaction not found for id: " + transactionId);
        }
        return response;
    }
    public List<TransactionEntity> getAllTransactions() {
        return dynamoDbClient.findAllTransactions();
    }

    @Override
    public void saveTransaction(TransactionEntity transactions) {
        dynamoDbClient.saveTransactions(transactions);
    }

    @Override
    public void saveTransactionReporting(TransactionReportingEntity transactionReportingEntity) {
        dynamoDbClient.saveTransactionReporting(transactionReportingEntity);
    }


    public void updateTransaction(TransactionEntity transaction) {
        dynamoDbClient.updateTransaction(transaction);
    }

}