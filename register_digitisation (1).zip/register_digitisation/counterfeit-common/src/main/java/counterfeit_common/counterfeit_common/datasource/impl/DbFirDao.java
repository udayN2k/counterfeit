package counterfeit_common.counterfeit_common.datasource.impl;

import counterfeit_common.counterfeit_common.common.exceptions.TransactionNotFoundException;
import counterfeit_common.counterfeit_common.datasource.clients.CounterfeitDynamoDbClient;
import counterfeit_common.counterfeit_common.datasource.entities.FIREntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class DbFirDao implements FirDao {

    private final CounterfeitDynamoDbClient dynamoDbClient;

    @Autowired
    public DbFirDao(CounterfeitDynamoDbClient dynamoDbClient) {
        this.dynamoDbClient = dynamoDbClient;
    }

    @Override
    public void saveFir(FIREntity fir){
        dynamoDbClient.saveFir(fir);
    }

    @Override
    public FIREntity findFIRByHashKey(String transactionId,String branchCode) {
        FIREntity response = dynamoDbClient.findFIRByHashKey(transactionId,branchCode);
        if (response == null) {
            throw new TransactionNotFoundException("Transaction not found for id: " + transactionId);
        }
        return response;
    }

    @Override
    public List<FIREntity> findByBranchCode(String branchCode) {
        List<FIREntity> response = dynamoDbClient.findByBranchCode(branchCode);
        if (response == null) {
            throw new TransactionNotFoundException("Transaction not found for branchCode: " + branchCode);
        }
        return response;
    }

    @Override
    public List<FIREntity> getAllFIR() {
        return dynamoDbClient.findAllFIR();
    }


}