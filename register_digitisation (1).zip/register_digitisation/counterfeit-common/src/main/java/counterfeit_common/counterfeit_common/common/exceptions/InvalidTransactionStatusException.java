package counterfeit_common.counterfeit_common.common.exceptions;

public class InvalidTransactionStatusException extends RuntimeException {
    public InvalidTransactionStatusException(String message) {
        super(message);
    }
}