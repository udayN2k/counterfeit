package counterfeit_rest.counterfeit_rest.controller;

import counterfeitNote_register.counterfeit.oas.api.TransactionControllerApi;
import counterfeitNote_register.counterfeit.oas.model.Transaction;
import counterfeitNote_register.counterfeit.oas.model.AddPoliceReportingDetails200Response;
import counterfeitNote_register.counterfeit.oas.model.ApproveTransaction200Response;
import counterfeitNote_register.counterfeit.oas.model.CreateTransaction201Response;
import counterfeitNote_register.counterfeit.oas.model.RejectTransaction200Response;
import counterfeitNote_register.counterfeit.oas.model.UpdateTransaction200Response;
import counterfeit_rest.counterfeit_rest.service.ApiService;
import counterfeit_rest.counterfeit_rest.service.CounterfeitService;
import counterfeit_rest.counterfeit_rest.service.FIRService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Date;
import java.util.List;

@Slf4j
@CrossOrigin(origins = {"http://localhost:5173"})
@RestController
@RequestMapping("/api/transactions")
public class CounterfeitController implements TransactionControllerApi {

    private final CounterfeitService counterfeitService;

    @Autowired
    public CounterfeitController(CounterfeitService counterfeitService) {
        this.counterfeitService = counterfeitService;

    }

    @Override
    public ResponseEntity<CreateTransaction201Response> createTransaction(
            @RequestParam String makerId,
            @RequestParam String makerName,
            @RequestParam String branchCode,
            @RequestBody Transaction transaction
            ) {
        return ResponseEntity.ok(counterfeitService.createTransaction(transaction, makerId, makerName, branchCode));
    }

    @Override
    public ResponseEntity<Transaction> getTransactionById(@PathVariable String recordId, @PathVariable Integer version) {
        return counterfeitService.getTransactionById(recordId, version);
    }

    @Override
    public ResponseEntity<List<Transaction>> getTransactionsWithFilters(
            @RequestParam(value = "status", required = false) List<String> status,
            @RequestParam(value = "denominations", required = false) List<Integer> denominations,
            @RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date fromDate,
            @RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date toDate) {
        return counterfeitService.getTransactionsWithFilters(status, denominations, fromDate, toDate);
    }

    @Override
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        return counterfeitService.getAllTransactions();
    }

    @Override
    public ResponseEntity<List<Transaction>> getTransactionsByMaker(@RequestParam String makerID) {
        return counterfeitService.getTransactionsByMaker(makerID);
    }

    @Override
    public ResponseEntity<List<Transaction>> getTransactionsByBranch(@RequestParam String branchCode) {
        return counterfeitService.getTransactionsByBranch(branchCode);
    }

    @Override
    public ResponseEntity<ApproveTransaction200Response> approveTransaction(
            @PathVariable String requestId,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @RequestBody Transaction updatedTransaction) {
        return counterfeitService.approveTransaction(requestId, checkerId, checkerName, updatedTransaction);
    }

    @Override
    public ResponseEntity<AddPoliceReportingDetails200Response> addPoliceReportingDetails(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @RequestBody Transaction transaction) {
        return counterfeitService.addPoliceReportingDetails(requestId, version, makerId, makerName, transaction);
    }

    @Override
    public ResponseEntity<RejectTransaction200Response> rejectTransaction(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String remarks,
            @RequestParam String checkerId,
            @RequestParam String checkerName) {
        return counterfeitService.rejectTransaction(requestId, version, remarks, checkerId, checkerName);
    }

    @Override
        public ResponseEntity<UpdateTransaction200Response> updateTransaction(
            @PathVariable String requestId,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @RequestBody Transaction transaction) {
        return counterfeitService.updateTransaction(requestId, makerId, makerName, transaction);
    }

}