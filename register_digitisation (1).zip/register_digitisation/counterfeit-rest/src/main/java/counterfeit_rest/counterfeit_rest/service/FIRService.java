package counterfeit_rest.counterfeit_rest.service;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMappingException;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import counterfeitNote_register.counterfeit.oas.model.Activity;
import counterfeitNote_register.counterfeit.oas.model.CreateFIR201Response;
import counterfeitNote_register.counterfeit.oas.model.FIR;
import counterfeitNote_register.counterfeit.oas.model.RequestCount;
import counterfeit_common.counterfeit_common.common.exceptions.TransactionNotFoundException;
import counterfeit_common.counterfeit_common.common.helper.CounterfeitDbHelper;
import counterfeit_common.counterfeit_common.datasource.entities.FIREntity;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Marker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.logging.Level;
import java.util.stream.Collectors;

@Slf4j
@Service
public class FIRService {

    private final CounterfeitDbHelper dbHelper;
    private static final String BRANCH_CODE = "8034";

    @Autowired
    public FIRService(CounterfeitDbHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public ResponseEntity<CreateFIR201Response> createFir(FIR firData, String checkerId, String checkerName, String branchCode) {
        try {
            calculatePendingWithPoliceEnd(firData);

            if (firData.getPostDate() == null) {
                LocalDateTime now = LocalDateTime.now();
                firData.setPostDate(now);
            }

            Activity checkerActivity = new Activity();
            checkerActivity.setId(checkerId);
            checkerActivity.setName(checkerName);

            if (firData.getChecker() == null) {
                firData.setChecker(new ArrayList<>());
            }
            firData.getChecker().add(checkerActivity);

            if(firData.getBranchCode() == null){
                firData.setBranchCode(branchCode);
            }

            FIREntity entity = convertToEntity(firData);
            entity.setFirReportId(generaterequestId());

            if(entity.getBranchCode() == null){
                entity.setBranchCode(branchCode);
            }

            dbHelper.saveFir(entity);

            log.info("FIR created and saved: {}", entity.getFirReportId());

            CreateFIR201Response response = new CreateFIR201Response()
                    .message("FIR created successfully")
                    .transactionId(entity.getFirReportId())
                    .pdfLink("https://example.com/transactions/" + entity.getFirReportId() + ".pdf"); // Replace with actual PDF link

            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            log.error("Failed to create transaction", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new CreateFIR201Response()
                    .message("Failed to create transaction"));
        }
    }

    private FIREntity convertToEntity(FIR firData) {
        FIREntity firEntity = new FIREntity();

        try {
            ObjectMapper objectMapper = new ObjectMapper();

            objectMapper.registerModule(new JavaTimeModule());

            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            Map<String, FIR> firDataMap = objectMapper.convertValue(firData, Map.class);
            firDataMap.remove("firReportId");
            firDataMap.remove("branchCode");

            firDataMap.entrySet().removeIf(entry -> entry.getValue() == null);

            firEntity.setFirData(firDataMap);

        } catch (IllegalArgumentException e) {
            log.error("Failed to convert FIR to entity: {}", firData.getFirReportId(), e);
        }

        return firEntity;
    }

    private FIR convertToDto(FIREntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("FIREntity cannot be null");
        }
        FIR transaction = new FIR();

        if (entity.getFirData() != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());

            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            try {
                transaction = objectMapper.convertValue(entity.getFirData(), FIR.class);
                transaction.setFirReportId(entity.getFirReportId());
                transaction.setBranchCode(entity.getBranchCode());
            } catch (IllegalArgumentException e) {
                log.error("Error converting TransactionEntity to Transaction: {}", e.getMessage());
                throw e;
            }
        }
        return transaction;
    }

    public ResponseEntity<FIR> getFIRById(String firReportId,String branchCode) {
        try {

            FIREntity firEntity = dbHelper.getFIRById(firReportId,branchCode);

            if (firEntity == null) {
                log.warn("Transaction not found for Id: {}", firReportId,branchCode);
                throw new TransactionNotFoundException(firReportId);
            }

            FIR firDTO = convertToDto(firEntity);
            log.info("Transaction fetched successfully: {}", firDTO);

            return new ResponseEntity<>(firDTO, HttpStatus.OK);

        } catch (TransactionNotFoundException e) {
            log.error(e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        } catch (DynamoDBMappingException e) {
            log.error("Failed to find FIRs: DynamoDBMappingException", e);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        } catch (RuntimeException e) {
            log.error("Failed to fetch FIR due to runtime exception: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Failed to fetch FIR due to unexpected error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<List<FIR>> findByBranchCode(String branchCode) {
        try {

            List<FIREntity> firEntity = dbHelper.findByBranchCode(branchCode);

            if (firEntity == null) {
                log.warn("Transaction not found for Id: {}", branchCode);
                throw new TransactionNotFoundException(branchCode);
            }
            List<FIR> firList = firEntity.stream()
                    .map(this::convertToDto)
                    .toList();
            log.info("Transaction fetched successfully: {}", firList);
            return new ResponseEntity<>(firList, HttpStatus.OK);
        } catch (TransactionNotFoundException e) {
            log.error(e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (DynamoDBMappingException e) {
            log.error("Failed to find FIR: DynamoDBMappingException", e);
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        } catch (RuntimeException e) {
            log.error("Failed to fetch FIR due to runtime exception: {}", e.getMessage());
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            log.error("Failed to fetch FIR due to unexpected error", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    public ResponseEntity<List<FIR>> getLastMonthFIRs(String branchCode) {
        try {
            // Fetch FIR entities from the database
            List<FIREntity> firEntity = dbHelper.findByBranchCode(branchCode);

            // Log the fetched result
            log.info("FIR Entity fetched successfully: {}", firEntity);

            if (firEntity == null || firEntity.isEmpty()) {
                log.warn("No FIRs found for branch code: {}", branchCode);
                return ResponseEntity.noContent().build(); // Return HTTP 204 No Content
            }

            // Convert entities to FIR DTOs
            List<FIR> firList = firEntity.stream()
                    .map(this::convertToDto)
                    .toList();

            // Get the current date and calculate previous month
            LocalDate now = LocalDate.now();
            LocalDate previousMonthDate = now.minusMonths(1);
            DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("MMMM");
            String previousMonth = previousMonthDate.format(monthFormatter);

            // Normalize the month name (e.g., "December" to "december")
            String lastMonth = previousMonth.toLowerCase();

            log.info("Last Month Data before {}:", lastMonth);

            // Filter the FIRs to only include those from the previous month
            List<FIR> lastMonthFIRs = firList.stream()
                    .filter(fir -> fir.getMonth().toLowerCase().equals(lastMonth))
                    .collect(Collectors.toList());

            log.info("Last Month Data after {}:", lastMonth);
            if (lastMonthFIRs.isEmpty()) {
                log.info("No FIRs found from the last month.");
            } else {
                log.info("{} FIR(s) found from last month", lastMonthFIRs.size());
                lastMonthFIRs.forEach(fir -> log.info("FIR Details: {}", fir));
            }

            // Return the result
            return ResponseEntity.ok(lastMonthFIRs);
        } catch (DynamoDBMappingException e) {
            log.error("Failed to find FIR: DynamoDBMappingException", e);
            return ResponseEntity.badRequest().build(); // Return HTTP 400 Bad Request
        } catch (RuntimeException e) {
            log.error("Failed to fetch FIR due to runtime exception: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Return HTTP 500 Internal Server Error
        } catch (Exception e) {
            log.error("Failed to fetch FIR due to unexpected error", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build(); // Return HTTP 500 Internal Server Error
        }
    }
    public ResponseEntity<List<FIR>> getAllFIR() {
        try {
            log.info("Fetching all FIRs");

            List<FIREntity> firEntities = dbHelper.getAllFIR();

            log.info("Fetched {} FIRs", firEntities.size());

            List<FIR> firList = firEntities.stream()
                    .map(this::convertToDto)
                    .toList();


            return new ResponseEntity<>(firList, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to fetch FIRs", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void calculatePendingWithPoliceEnd(FIR fir) {
        if (fir.getPendingWithPoliceBegining() != null &&
                fir.getSendToPolice() != null &&
                fir.getReturnByPolice() != null) {

            int pendingFirCountBegin = 0;
            int sendFirCount = 0;
            int returnFirCount = 0;

            int pendingNoteCountBegin = 0;
            int sendNoteCount = 0;
            int returnNoteCount = 0;

            for (RequestCount count : fir.getPendingWithPoliceBegining()) {
                pendingFirCountBegin += count.getFirCount();
                pendingNoteCountBegin += count.getNoteCount();
            }

            for (RequestCount count : fir.getSendToPolice()) {
                sendFirCount += count.getFirCount();
                sendNoteCount += count.getNoteCount();
            }

            for (RequestCount count : fir.getReturnByPolice()) {
                returnFirCount += count.getFirCount();
                returnNoteCount += count.getNoteCount();
            }

            int pendingFirCountEnd = pendingFirCountBegin + sendFirCount - returnFirCount;
            int pendingNoteCountEnd = pendingNoteCountBegin + sendNoteCount - returnNoteCount;

            RequestCount pendingWithPoliceEnd = new RequestCount();
            pendingWithPoliceEnd.setFirCount(pendingFirCountEnd);
            pendingWithPoliceEnd.setNoteCount(pendingNoteCountEnd);

            fir.setPendingWithPoliceEnd(Collections.singletonList(pendingWithPoliceEnd));
        }
    }
    private String generaterequestId() {
        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyy");
        String formattedDate = now.format(formatter).replace("-", "");

        String timestampSuffix = String.valueOf(System.currentTimeMillis() % 10000);

        String requestId = BRANCH_CODE + formattedDate + timestampSuffix;

        log.info("Generated requestId: " + requestId);

        return requestId;
    }

    public ResponseEntity<List<FIR>> getFilters(Date fromDate, Date toDate) {
        try {
            log.info("Fetching FIRs with date range: {} to {}", fromDate, toDate);

            List<FIREntity> firList = dbHelper.getAllFIR();

            if (firList == null || firList.isEmpty()) {
                log.warn("No FIRs found.");
                return ResponseEntity.notFound().build();
            }

            List<FIR> filteredFIR = firList.stream()
                    .filter(firEntity -> filterByDateRange(firEntity, fromDate, toDate))
                    .map(this::convertToDto)
                    .collect(Collectors.toList());

            log.info("Fetched {} FIRs within the date range", filteredFIR.size());

            return ResponseEntity.ok(filteredFIR);
        } catch (Exception e) {
            log.error("Error occurred while filtering FIRs: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    private boolean filterByDateRange(FIREntity firEntity, Date fromDate, Date toDate) {
        try {
            if (fromDate == null && toDate == null) {
                return true; // No filtering needed
            }

            String postDateStr = String.valueOf(firEntity.getFirData().get("postDate"));
            Date postDate = parseDate(postDateStr);

            if (postDate == null) {
                return false; // If the date can't be parsed, don't include this FIR
            }

            boolean isAfterFromDate = (fromDate == null || !postDate.before(fromDate));
            boolean isBeforeToDate = (toDate == null || !postDate.after(toDate));
            return isAfterFromDate && isBeforeToDate;
        } catch (Exception e) {
            log.error("Error filtering FIR by date range: {} to {}", fromDate, toDate, e);
            return false; // In case of error, exclude this FIR
        }
    }
    public Date parseDate(String dateString) {
        if (dateString.startsWith("[") && dateString.endsWith("]") && dateString.length() > 2) {
            String[] parts = dateString.substring(1, dateString.length() - 1).split(", ");
            if (parts.length == 5) {
                int year = Integer.parseInt(parts[0]);
                int month = Integer.parseInt(parts[1]) - 1; // Month is 0-based in Java
                int day = Integer.parseInt(parts[2]);
                int hour = Integer.parseInt(parts[3]);
                int minute = Integer.parseInt(parts[4]);

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day, hour, minute);
                return calendar.getTime();
            }
        }
        log.error("Invalid date string: {}", dateString);
        return null;
    }
    public List<FIR> getLastMonthFIRs(List<FIR> firList) {
        List<FIR> lastMonthFIRs = new ArrayList<>();
        Calendar calendar = Calendar.getInstance();

        // Setting the calendar to first day of last month
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, -1);
        Date firstDayOfLastMonth = calendar.getTime();

        // Setting the calendar to first day of this month
        calendar.set(Calendar.DAY_OF_MONTH, 1);
        calendar.add(Calendar.MONTH, 1);
        Date firstDayOfCurrentMonth = calendar.getTime();

        for (FIR fir : firList) {
            LocalDateTime postDateTime = fir.getPostDate(); // Assuming this returns LocalDateTime

            // Convert LocalDateTime to Date
            ZonedDateTime zonedDateTime = postDateTime.atZone(ZoneId.systemDefault());
            Date postDate = Date.from(zonedDateTime.toInstant());

            // Check if postDate is in last month
            if (postDate.after(firstDayOfLastMonth) && postDate.before(firstDayOfCurrentMonth)) {
                lastMonthFIRs.add(fir);
            }
        }

        if (lastMonthFIRs.isEmpty()) {
            log.info((Marker) Level.INFO, "No FIRs found from last month.");
            return lastMonthFIRs;
        }

        log.info((Marker) Level.INFO, lastMonthFIRs.size() + " FIR(s) found from last month.");
        for (FIR fir : lastMonthFIRs) {
            log.info((Marker) Level.INFO, fir.toString());
        }

        return lastMonthFIRs;
    }
}
