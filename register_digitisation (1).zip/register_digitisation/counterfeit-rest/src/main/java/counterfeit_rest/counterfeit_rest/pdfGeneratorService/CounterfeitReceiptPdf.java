package counterfeit_rest.counterfeit_rest.pdfGeneratorService;

import com.itextpdf.io.font.constants.StandardFonts;

import java.util.List;
import java.util.Locale;

import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.canvas.draw.SolidLine;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.borders.SolidBorder;
import counterfeitNote_register.counterfeit.oas.model.Note;
import counterfeitNote_register.counterfeit.oas.model.TransactionReporting;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
@Service
public class CounterfeitReceiptPdf {

    @Value("${kotak.image.path}")
    public String kotakLogo;

    public String tendererName;
    public float nameLen;
    public String tendererAddress;
    public float addressLen;

    public byte[] generatePdf(TransactionReporting transaction, String requestId, String type) {
        String formattedDate = transaction.getRecordId().substring(4, 10);

        if (transaction.getCustomerName() != null) {
            tendererName = transaction.getCustomerName();
            nameLen = 252f - (tendererName.length() * 5);
        }

        if (transaction.getCustomerAddress() != null) {
            tendererAddress = transaction.getCustomerAddress();
            addressLen = 500 - (tendererAddress.length() * 5);
        }

        LocalDateTime transactionDateTime = transaction.getCreationDate();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a", Locale.ENGLISH);

        String dateAndTime = transactionDateTime.format(formatter);

        String CustomerName = transaction.getCustomerName();


        String UserId = transaction.getMaker().get(0).getId();

        String makerIdName = CustomerName +", "+ UserId;

        List<Note> noteDetailsList = transaction.getNoteDetails();

        int noteCount = noteDetailsList.size();
        int notesPerPage = 5;
        int numberOfPages = (int) Math.ceil(noteCount / (double) notesPerPage);

        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            PdfWriter writer = new PdfWriter(byteArrayOutputStream);
            PdfDocument pdf = new PdfDocument(writer);
            pdf.setDefaultPageSize(PageSize.A4);
            Document document = new Document(pdf);

            for (int pageIndex = 0; pageIndex < numberOfPages; pageIndex++) {
                Table outerTable = new Table(1);
                outerTable.setWidth(UnitValue.createPercentValue(100));
                outerTable.setMarginTop(-1);
                outerTable.setMarginBottom(-25);
                outerTable.setMarginRight(-25);
                outerTable.setMarginLeft(-25);
                outerTable.setBorder(new SolidBorder(ColorConstants.BLACK, 1));

                Cell mainCell = new Cell();
                mainCell.setBorder(null);

                Table logoTable = new Table(new float[]{1})
                        .setHeight(70)
                        .setBackgroundColor(ColorConstants.BLACK);

                File imageFile = new File(kotakLogo);
                if (imageFile.exists()) {
                    try {
                        Image logo = new Image(ImageDataFactory.create(kotakLogo));
                        logo.scaleToFit(570f, 1500f);
                        logo.setHorizontalAlignment(HorizontalAlignment.CENTER);

                        Cell logoCell = new Cell();
                        logoCell.add(logo)
                                .setPaddingTop(10)
                                .setBorder(null)
                                .setMargin(10);
                        logoTable.addCell(logoCell);
                    } catch (MalformedURLException e) {
                        log.error("Error loading image: " + e.getMessage());
                    }
                } else {
                    log.error("Image file not found at: {}", kotakLogo);
                }

                mainCell.add(logoTable.setMargin(-3));

                Paragraph title = new Paragraph("Acknowledgment Receipt for Counterfeit Note/s").setTextAlignment(TextAlignment.CENTER).setBold().setFontSize(14).setMarginTop(30);
                mainCell.add(title);

                Paragraph branchInfo = new Paragraph("Address of the Bank Branch:").setFontSize(12).setTextAlignment(TextAlignment.LEFT).setBold().setMarginTop(30).setPaddingLeft(10);
                mainCell.add(branchInfo);

                Paragraph copyType = new Paragraph(type).setFontSize(12).setTextAlignment(TextAlignment.RIGHT).setBold().setPaddingTop(-20).setMarginBottom(22).setPaddingRight(30);
                mainCell.add(copyType);

                Table receiptTables = new Table(new float[]{1, 1, 1, 1, 1, 1, 1});
                receiptTables.setWidth(UnitValue.createPercentValue(100)).setMarginTop(20);

                Cell cell1r1c = new Cell().add(new Paragraph("Sr. Number of Receipt")).setBorder(Border.NO_BORDER).setPadding(1).setFontSize(12).setBold().setPaddingLeft(10);
                receiptTables.addCell(cell1r1c);
                Cell cell1r2c = new Cell();
                Table innerTable1r2c = new Table(4).setMarginLeft(-25).setMarginTop(-5);

                for (int i = 0; i < 4; i++) {
                    char character = requestId.charAt(i);
                    innerTable1r2c.addCell(new Cell()
                            .add(new Paragraph(String.valueOf(character)).setFontSize(8))
                            .setMarginTop(-5)
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                            .setHeight(12)
                            .setWidth(12)
                            .setTextAlignment(TextAlignment.CENTER));
                }

                cell1r2c.add(innerTable1r2c)
                        .setPaddingLeft(0)
                        .setBorder(Border.NO_BORDER)
                        .setPadding(5);

                receiptTables.addCell(cell1r2c);

                Cell cell1r3c = new Cell();
                Table innerTable1r3c = new Table(6).setMarginTop(-1).setMarginLeft(-8);
                for (int i = 0; i < 6; i++) {
                    char character1 = formattedDate.charAt(i);
                    innerTable1r3c.addCell(new Cell().add(new Paragraph(String.valueOf(character1)).setFontSize(8))
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setHeight(12).setWidth(12)).setTextAlignment(TextAlignment.CENTER);
                }
                cell1r3c.add(innerTable1r3c).setBorder(Border.NO_BORDER).setPadding(1);
                receiptTables.addCell(cell1r3c);

                Cell cell1r4c = new Cell();
                Table innerTable1r4c = new Table(4).setMarginLeft(-10).setMarginTop(-1);
                for (int i = 0; i < 4; i++) {
                    char character2 = requestId.charAt(i);
                    innerTable1r4c.addCell(new Cell().add(new Paragraph(String.valueOf(character2)).setFontSize(8))
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                            .setHeight(12).setWidth(12)).setTextAlignment(TextAlignment.CENTER);
                }
                cell1r4c.add(innerTable1r4c)
                        .setBorder(Border.NO_BORDER)
                        .setPadding(1);
                receiptTables.addCell(cell1r4c);

                Cell cell1r5c = new Cell().setBorder(Border.NO_BORDER);
                receiptTables.addCell(cell1r5c);

                Cell cell1r6c = new Cell().add(new Paragraph("Date:").setTextAlignment(TextAlignment.RIGHT)).setBorder(Border.NO_BORDER).setPaddings(-1, -3, 1, 3);
                receiptTables.addCell(cell1r6c);

                Cell cell1r7c = new Cell();
                Table innerTable1r6c = new Table(6).setMarginLeft(3);
                for (int i = 0; i < 6; i++) {
                    char character3 = formattedDate.charAt(i);
                    innerTable1r6c.addCell(new Cell().add(new Paragraph(String.valueOf(character3)).setFontSize(8))
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                            .setHeight(12).setWidth(12)).setTextAlignment(TextAlignment.CENTER);
                }
                cell1r7c.add(innerTable1r6c).setBorder(Border.NO_BORDER).setPadding(1).setPaddingTop(-1);
                receiptTables.addCell(cell1r7c);

                Cell cell1c2r = new Cell().setBorder(Border.NO_BORDER).setPadding(1);
                receiptTables.addCell(cell1c2r);

                Cell cell2c2r = new Cell().add(new Paragraph("(Branch Code)")).setBorder(Border.NO_BORDER).setFontColor(ColorConstants.LIGHT_GRAY).setPadding(1).setFontSize(10).setTextAlignment(TextAlignment.CENTER).setPaddings(-3, 1, 1, -30);
                receiptTables.addCell(cell2c2r);

                Cell cell3c2r = new Cell().add(new Paragraph("(Date-DD/MM/YY)")).setBorder(Border.NO_BORDER).setFontColor(ColorConstants.LIGHT_GRAY).setPadding(1).setFontSize(10).setPaddings(-3, 1, 1, 8);
                receiptTables.addCell(cell3c2r);

                Cell cell4c2r = new Cell(1, 1);
                Table innerTable4c2r = new Table(4).setMarginLeft(-10).setMarginTop(-1);
                cell4c2r.add(innerTable4c2r)
                        .setBorder(Border.NO_BORDER)
                        .setPadding(1);

                Paragraph descriptionParagraph = new Paragraph("Running\n" + "serial no. of the\n" + " branch")
                        .setFontSize(10)
                        .setTextAlignment(TextAlignment.CENTER)
                        .setMarginBottom(0)
                        .setMarginLeft(-2)
                        .setPaddingLeft(-13)
                        .setPaddingTop(-3)
                        .setFontColor(ColorConstants.LIGHT_GRAY);

                cell4c2r.add(descriptionParagraph);
                receiptTables.addCell(cell4c2r);

                Cell cell6c2r = new Cell().setBorder(Border.NO_BORDER);
                receiptTables.addCell(cell6c2r);

                Cell cell7c2r = new Cell().setBorder(Border.NO_BORDER);
                receiptTables.addCell(cell7c2r);

                Cell additionalInfoCell = new Cell()
                        .add(new Paragraph("(Date-DD/MM/YY)").setFontColor(ColorConstants.LIGHT_GRAY).setFontSize(10))
                        .setBorder(Border.NO_BORDER)
                        .setTextAlignment(TextAlignment.LEFT)
                        .setPaddingTop(-3)
                        .setPaddingLeft(15);
                receiptTables.addCell(additionalInfoCell);

                mainCell.add(receiptTables);
                mainCell.add(new Paragraph("\n").setFontSize(8));

                Paragraph tendererInfo = new Paragraph()
                        .add(new Text("The currency note(s) described below received from ").setFontSize(12))
                        .add(new Text(tendererName).setFontSize(12).setUnderline())
                        .add(new LineSeparator(new SolidLine(0.75f)).setWidth(nameLen).setMarginBottom(-1.65f))
                        .add(new Text("\n" + tendererAddress).setFontSize(12).setUnderline())
                        .add(new LineSeparator(new SolidLine(0.75f)).setWidth(addressLen).setMarginBottom(-1.65f))
                        .add(new Text("\n(Name and address of the tenderer) is/are Counterfeit and has/have therefore been impounded and stamped accordingly."))
                        .setFontSize(12).setPaddingLeft(10).setMarginTop(-5);
                mainCell.add(tendererInfo);

                Table notesTable;

                    notesTable = new Table(new float[]{2, 2, 4})
                            .setWidth(UnitValue.createPercentValue(100)).setFontSize(12)
                            .setMarginTop(20).setMarginLeft(-3).setMarginRight(-19);


                notesTable.addHeaderCell(new Cell()
                        .add(new Paragraph("Sr. No. of the Note").setBold()).setTextAlignment(TextAlignment.CENTER)
                        .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setPadding(8));

                notesTable.addHeaderCell(new Cell()
                        .add(new Paragraph("Denomination").setBold()).setTextAlignment(TextAlignment.CENTER)
                        .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setPadding(8));

                notesTable.addHeaderCell(new Cell(1, 2)
                        .add(new Paragraph("Parameter on which note is deemed counterfeit").setBold())
                        .setTextAlignment(TextAlignment.CENTER).setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                        .setPadding(8));

                int startIndex = pageIndex * notesPerPage;
                int endIndex = Math.min(startIndex + notesPerPage, noteCount);

                for (int i = startIndex; i < endIndex; i++) {
                    Note noteDetails = noteDetailsList.get(i);
                    notesTable.addCell(
                            new Cell()
                                    .add(new Paragraph(noteDetails.getSerialNumber())).setHeight(20).setTextAlignment(TextAlignment.CENTER)
                                    .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setPadding(8));

                    notesTable.addCell(
                            new Cell()
                                    .add(new Paragraph(String.valueOf(noteDetails.getDenomination()))).setHeight(20).setTextAlignment(TextAlignment.CENTER)
                                    .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setPadding(8));

                    String breachedFeatures = String.join(", ", noteDetails.getSecurityFeatureBreached());
                    notesTable.addCell(
                            new Cell()
                                    .add(new Paragraph(breachedFeatures)).setHeight(20).setTextAlignment(TextAlignment.CENTER)
                                    .setBorder(new SolidBorder(ColorConstants.BLACK, 1)).setPadding(8));
                }

                    notesTable.addCell(new Cell(1, 1)
                                    .add(new Paragraph("Total No. of Notes:").setBold())
                                    .setPaddingTop(10)
                                    .setPaddingRight(15)
                                    .setTextAlignment(TextAlignment.RIGHT))
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                            .setPadding(8);

                    notesTable.addCell(new Cell(1, 2)
                            .add(new Paragraph(String.valueOf(noteCount)))
                            .setBorder(new SolidBorder(ColorConstants.BLACK, 1))
                            .setPadding(8));
                mainCell.add(notesTable);

                Table signatureTable = new Table(new float[]{2, 2})
                        .setWidth(UnitValue.createPercentValue(100))
                        .setFontSize(12)
                        .setMarginTop(15)
                        .setMarginBottom(-20);

                signatureTable.addCell(new Cell()
                        .add(new Paragraph("\n\n(Signature of the tenderer)"))
                        .setBorder(null)
                        .setPaddingLeft(10));

                Cell cashierCell = new Cell()
                        .setBorder(null)
                        .setPaddingLeft(100);

                cashierCell.add(new Paragraph("\n\n(Signature of the counter cashier)").setTextAlignment(TextAlignment.RIGHT))
                        .setPaddingRight(42);

                signatureTable.addCell(cashierCell);

                mainCell.add(signatureTable);

                Table infoTable = new Table(new float[]{1, 1})
                        .setWidth(UnitValue.createPercentValue(100))
                        .setMarginTop(30);

                Paragraph contactParagraph = new Paragraph()
                        .add(new Text("Contact number of the tenderer: ______________ ").setFontSize(12))
                        .setPaddingLeft(8)
                        .setPaddingTop(12)
                        .setMarginTop(-5);

                Cell contactCell = new Cell()
                        .add(contactParagraph)
                        .setBorder(Border.NO_BORDER)
                        .setHeight(40);

                infoTable.addCell(contactCell);

                Paragraph employeeInfoParagraph = new Paragraph()
                        .add(new Text(makerIdName).setFontSize(12))
                        .setMarginTop(-5)
                        .setUnderline();

                Paragraph cashierInfoParagraph = new Paragraph()
                        .add(new Text("Name, Employee Number:").setFontSize(12))
                        .setMarginTop(-5);

                Paragraph dateTimeParagraph = new Paragraph()
                        .add(new Text("Date & Time: ").setFontSize(12))
                        .add(new Text(dateAndTime != null ? dateAndTime : "_______________")
                                .setFontSize(12)
                                .setUnderline())
                        .setMarginTop(-5);

                Paragraph newParagraph = new Paragraph()
                        .add(new Text(" ").setFontSize(12))
                        .add(new Text(" ").setFontSize(12));


                Cell dateTimeCell = new Cell()
                        .add(employeeInfoParagraph)
                        .add(cashierInfoParagraph)
                        .add(dateTimeParagraph)
                        .setPaddingRight(-12)
                        .setBorder(Border.NO_BORDER);
                infoTable.addCell(dateTimeCell);

                if (pageIndex != numberOfPages - 1) {
                    Cell demoCell = new Cell()
                            .add(newParagraph)
                            .add(newParagraph)
                            .add(newParagraph)
                            .setBorder(new SolidBorder(ColorConstants.WHITE, 1));
                    infoTable.addCell(demoCell);
                }

                mainCell.add(infoTable);

                outerTable.addCell(mainCell);
                document.add(outerTable);

                addFooter(pdf, pdf.getNumberOfPages(), 10);
            }
            document.close();
            log.info("PDF Created!");
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return new ByteArrayOutputStream().toByteArray();
    }

    private static void addFooter(PdfDocument pdf, int pageIndex, float footerOffset) {
        PdfPage page = pdf.getPage(pageIndex);
        PdfCanvas pdfCanvas = new PdfCanvas(page);

        PdfFont regularFont = null;
        PdfFont boldFont = null;
        try {
            regularFont = PdfFontFactory.createFont(StandardFonts.HELVETICA);
            boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD);
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }

        Text boldText1 = new Text("Kotak Mahindra Bank Ltd. ").setFont(boldFont);
        Text regularText1 = new Text("CIN: L65110MH1985PLC03813 ");
        Text boldText2 = new Text("Registered Office: ").setFont(boldFont);
        Text regularText2 = new Text("27 BKC, C 27, G Block, Bandra" +
                " Kurla Complex, Bandra (E), Mumbai - 400 051. ");

        Text urlText = new Text("www.kotak.com")
                .setFont(regularFont)
                .setFontColor(ColorConstants.BLUE)
                .setUnderline()
                .setAction(com.itextpdf.kernel.pdf.action.PdfAction.createURI("https://www.kotak.com"));

        Paragraph footer = new Paragraph()
                .add(boldText1).add(regularText1).add(boldText2).add(regularText2).add(urlText);
        Rectangle pageSize = page.getPageSize();
        float x = pageSize.getWidth() / 50;
        float y = pageSize.getBottom() + footerOffset;

        if (y < pageSize.getBottom() + 2) {
            y = pageSize.getBottom() + 2;
        }

        Canvas canvas = new Canvas(pdfCanvas, pageSize);
        canvas.setFontSize(7);
        canvas.showTextAligned(footer, x, y, TextAlignment.LEFT);
        canvas.close();
    }
}