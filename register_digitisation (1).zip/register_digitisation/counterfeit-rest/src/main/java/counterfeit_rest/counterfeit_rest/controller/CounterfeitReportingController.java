    package counterfeit_rest.counterfeit_rest.controller;

    import counterfeitNote_register.counterfeit.oas.api.TransactionReportingControllerApi;
    import counterfeit_rest.counterfeit_rest.service.CounterfeitService;
    import org.springframework.core.io.ByteArrayResource;
    import org.springframework.core.io.Resource;
    import org.springframework.http.HttpHeaders;
    import org.springframework.http.MediaType;
    import org.springframework.http.ResponseEntity;
    import org.springframework.web.bind.annotation.PathVariable;
    import org.springframework.web.bind.annotation.RequestParam;

    public class CounterfeitReportingController implements TransactionReportingControllerApi {

        private final CounterfeitService counterfeitService;

        public CounterfeitReportingController(CounterfeitService counterfeitService) {
            this.counterfeitService = counterfeitService;
        }

        @Override
        public ResponseEntity<Resource> downloadPdf(@PathVariable String requestId,
                                                    @RequestParam String copyType) {
            byte[] pdfBytes = counterfeitService.readPdfAsBytes(requestId, copyType);
            ByteArrayResource resource = new ByteArrayResource(pdfBytes);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", requestId + ".pdf");

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(resource);
        }
    }
