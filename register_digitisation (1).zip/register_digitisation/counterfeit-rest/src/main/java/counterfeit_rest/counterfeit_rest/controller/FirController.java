package counterfeit_rest.counterfeit_rest.controller;

import counterfeitNote_register.counterfeit.oas.api.FirControllerApi;
import counterfeitNote_register.counterfeit.oas.model.CreateFIR201Response;
import counterfeitNote_register.counterfeit.oas.model.FIR;
import counterfeit_rest.counterfeit_rest.service.ApiService;
import counterfeit_rest.counterfeit_rest.service.CounterfeitService;
import counterfeit_rest.counterfeit_rest.service.FIRService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
public class FirController implements FirControllerApi {

    private final FIRService firService;
    private final CounterfeitService counterfeitService;

    private final ApiService apiService;


    public FirController(FIRService firService, CounterfeitService counterfeitService, ApiService apiService) {
        this.firService = firService;
        this.counterfeitService = counterfeitService;
        this.apiService = apiService;
    }


    @Override
    public ResponseEntity<CreateFIR201Response> createFIR(
            @RequestBody FIR fir,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @RequestParam String branchCode) {

        return firService.createFir(fir, checkerId, checkerName, branchCode);

    }

    @Override
    public ResponseEntity<FIR> getFIRById(@PathVariable String requestId, @PathVariable String branchCode) {

        return firService.getFIRById(requestId, branchCode);

    }

    @Override
    public ResponseEntity<List<FIR>> findByBranchCode(@PathVariable String branchCode) {

        return firService.findByBranchCode(branchCode);

    }
    @Override
    public ResponseEntity<List<FIR>> getLastMonthFIRs(@PathVariable String branchCode) {
        return firService.getLastMonthFIRs(branchCode);

    }

    @Override
    public ResponseEntity<List<Integer>> getTotalFIRPerMonth(String branchCode) {
        return counterfeitService.getTotalFIRPerMonth(branchCode);
    }

    @Override
    public ResponseEntity<List<FIR>> getFilters(
            @RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date fromDate,
            @RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date toDate) {

        return firService.getFilters(fromDate, toDate);

    }

    @Override
    public ResponseEntity<Map<String, String>> getAccountDetails(@PathVariable String accountId) {

        Map<String, String> accountDetails = apiService.fetchAccountDetails(accountId);

        if (accountDetails == null) {
            log.warn("Account details not found for accountId: {}", accountId);
            return ResponseEntity.notFound().build();
        }

        log.info("Successfully fetched account details for accountId: {}", accountId);
        return ResponseEntity.ok(accountDetails);
    }


    @Override
    public ResponseEntity<List<FIR>> getAllFIR() {
        return firService.getAllFIR();

    }

}
