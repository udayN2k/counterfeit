package counterfeit_rest.counterfeit_rest.service;

import java.util.UUID;

public class XmlRequestBuilder {

    public String buildRequest(String forAccountId) {
        String requestUUID = UUID.randomUUID().toString();
        String messageDateTime = "2020-10-16T07:09:54.507Z";

        String xmlRequest = String.format(
                """
                <FIXML xmlns="http://www.finacle.com/fixml">
                    <Header>
                        <RequestHeader>
                            <MessageKey>
                                <RequestUUID>%s</RequestUUID>
                                <ServiceRequestId>executeFinacleScript</ServiceRequestId>
                                <ServiceRequestVersion>10.2</ServiceRequestVersion>
                                <ChannelId>COR</ChannelId>
                            </MessageKey>
                            <RequestMessageInfo>
                                <BankId>01</BankId>
                                <TimeZone/>
                                <EntityId/>
                                <EntityType/>
                                <ArmCorrelationId/>
                                <MessageDateTime>%s</MessageDateTime>
                            </RequestMessageInfo>
                            <Security>
                                <Token>
                                    <PasswordToken>
                                        <UserId/>
                                        <Password/>
                                    </PasswordToken>
                                </Token>
                                <FICertToken/>
                                <RealUserLoginSessionId/>
                                <RealUser/>
                                <RealUserPwd/>
                                <SSOTransferToken/>
                            </Security>
                        </RequestHeader>
                    </Header>
                    <Body>
                        <executeFinacleScriptRequest>
                            <ExecuteFinacleScriptInputVO>
                                <requestId>intf_CustomAcctInq_main.scr</requestId>
                            </ExecuteFinacleScriptInputVO>
                            <executeFinacleScript_CustomData>
                                <Foracid>%s</Foracid>
                            </executeFinacleScript_CustomData>
                        </executeFinacleScriptRequest>
                    </Body>
                </FIXML>
                """,
                requestUUID, messageDateTime, forAccountId
        );

        return xmlRequest;
    }

    public String buildCrnRequest(String crn) {
        String requestUUID = UUID.randomUUID().toString();

        String xmlRequest = String.format(
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<Request xmlns=\"http://www.kotak.com/schemas/crn_full_details.xsd\">\n" +
                        "    <sourceappcode>DECIMAL</sourceappcode>\n" +
                        "    <RqUID>%s</RqUID>\n" +
                        "    <action_type>CRN_DYNAMIC_DETAILS</action_type>\n" +
                        "    <bcif_id>%s</bcif_id>\n" +
                        "</Request>",
                requestUUID, crn
        );

        return xmlRequest;
    }
}