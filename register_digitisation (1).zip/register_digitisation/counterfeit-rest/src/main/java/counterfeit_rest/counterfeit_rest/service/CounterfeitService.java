package counterfeit_rest.counterfeit_rest.service;

import com.fasterxml.jackson.annotation.JsonInclude;
import counterfeitNote_register.counterfeit.oas.model.*;
import counterfeit_common.counterfeit_common.common.helper.ErrorResponse;
import counterfeit_common.counterfeit_common.common.helper.Problem;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import counterfeit_common.counterfeit_common.common.exceptions.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import counterfeit_common.counterfeit_common.common.helper.CounterfeitDbHelper;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionReportingEntity;
import counterfeit_common.counterfeit_common.datasource.util.ObjectMapperUtil;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionEntity;
import counterfeit_workers.objects.WorkflowInput;
import counterfeit_rest.counterfeit_rest.pdfGeneratorService.CounterfeitReceiptPdf;
import counterfeit_workers.objects.ActionUserType;
import counterfeit_workers.workflows.api.CounterfeitWorkflow;
import io.temporal.client.WorkflowClient;
import io.temporal.api.common.v1.WorkflowExecution;
import io.temporal.client.WorkflowOptions;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.List;
import java.util.Date;

import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.time.temporal.ChronoUnit;
import java.util.stream.Collectors;

import org.springframework.scheduling.annotation.Scheduled;

import static counterfeit_common.counterfeit_common.datasource.util.EncryptionUtil.*;

@Slf4j
@Service
public class CounterfeitService {

    private final CounterfeitDbHelper dbHelper;
    private final CounterfeitReceiptPdf pdf;
    private final WorkflowClient workflowClient;
    private static final String BRANCH_CODE = "8034";
    @Value("${pdf_Directory.path}")
    private String pdfDirectory;

    private String pdfPath = "C:/Users/KXT76844/KotakRepo/counterfeitNotesRegister/register_digitisation/counterfeit-rest/resources";
    private static final String MESSAGE = "message";
    private static final String SUBMITTED = "CHECKER_IN_PROGRESS";
    private static final String REQUEST_ID = "recordId";
    private static final String REGISTER_TYPE = "COUNTERFEIT";
    private static final String RE_SUBMITTED = "CHECKER_IN_PROGRESS";
    private static final String APPROVED = "APPROVED";
    private static final String REJECTED = "MAKER_IN_PROGRESS";
    private static final String TRANSACTION_NOT_FOUND_MESSAGE = "Transaction not found for recordId: ";

    @Autowired
    public CounterfeitService(CounterfeitDbHelper dbHelper, ObjectMapper objectMapper, CounterfeitReceiptPdf pdf, WorkflowClient workflowClient) {

        this.dbHelper = dbHelper;
        this.pdf = pdf;
        this.workflowClient = workflowClient;
    }

    public CreateTransaction201Response createTransaction(Transaction transaction, String makerId, String makerName, String branchCode) {

        List<Problem> validationProblems = new ArrayList<>();

        boolean isValid = validateTransactionFields(transaction, validationProblems);

        if (!isValid) {
            throw ManagedException.builder()
                    .problems(validationProblems)
                    .build();
        }

        try {
            if (transaction.getCreationDate() == null) {
                LocalDateTime now = LocalDateTime.now();
                transaction.setCreationDate(now);
            }

            transaction.setStatus(Optional.ofNullable(transaction.getStatus()).orElse(SUBMITTED));

            transaction.setUserAction("SUBMIT");
            transaction.setRegisterType(REGISTER_TYPE);
            transaction.setUserType("MAKER");
            transaction.setUpdatedTime(transaction.getCreationDate());
            //           transaction.setDocuments(Collections.singletonList(pdfDirectory));
            setNoteCount(transaction);

            transaction.setUserRemarks(setUserRemarks(transaction, makerId));

//            Activity branchActivity = new Activity();
//
//                branchActivity.setId(transaction.getBranchDetails().getId());
//                branchActivity.setName(transaction.getBranchDetails().getName());
//                transaction.setBranchDetails(branchActivity);

            Activity makerActivity = new Activity();
            makerActivity.setId(makerId);
            makerActivity.setName(makerName);

            transaction.setMaker(List.of(makerActivity));

            String recordId = generateRequestId();

            encryptTransactionDetails(transaction);

            TransactionEntity transactionEntity = convertToEntity(transaction);
            transactionEntity.setVersion(transaction.getVersion());
            transactionEntity.setRecordId(recordId);

            if (recordId != null && !recordId.isEmpty()) {
                dbHelper.saveTransaction(transactionEntity);
            } else
                log.info("RecordId cannot be null:");
            transaction.setRecordId(transactionEntity.getRecordId());

            saveReportingTransaction(transaction);

            log.info("Transaction created and saved: {}", transactionEntity.getRecordId());

            String pdfLink = pdfDirectory + recordId + ".pdf";

             startWorkflow(transaction, transactionEntity, recordId, pdfLink);

            CreateTransaction201Response response = new CreateTransaction201Response();
            response.setMessage("Transaction created successfully");
            response.setPdfLink(pdfLink);
            response.setTransactionId(transactionEntity.getRecordId());

            return response;

        } catch (Exception e) {
            log.error("Error during transaction creation", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_CREATING_TRANSACTION")
                            .message("An unexpected error occurred while creating the transaction")
                            .build()))
                    .build();
        }
    }

    private void saveReportingTransaction(Transaction transaction) {

        TransactionReporting report = new TransactionReporting();

        String transactionId = generateTransactionId(transaction);
        report.setTransactionId(transactionId);
        report.setCustomerName(transaction.getCustomerName());
        report.setCustomerNumber(transaction.getCustomerNumber());
        report.setCustomerAddress(transaction.getCustomerAddress());
        report.setBranchDetails(transaction.getBranchDetails());
        report.setRegister(transaction.getRegisterType());
        report.setMaker(transaction.getMaker());
        report.setChecker(transaction.getChecker());
        report.setNoteDetails(transaction.getNoteDetails());
        report.setStatus(transaction.getStatus());
        //       report.setDocuments("");
        report.setCheckerVerificationDate(transaction.getCheckerApprovalDate());
        report.setCreationDate(transaction.getCreationDate());
        report.setUserRemarks(transaction.getUserRemarks());

        TransactionReportingEntity transactionReportingEntity = convertToReportEntity(report);

        transactionReportingEntity.setRecordId(transaction.getRecordId());

        if (transactionId != null && !transactionId.isEmpty()) {
            dbHelper.saveTransactionReporting(transactionReportingEntity);
        } else
            log.info("transactionId cannot be null:");
    }

    private ResponseEntity<Map<String, Object>> startWorkflow(Transaction transaction, TransactionEntity transactionEntity, String recordId, String pdfLink) {
        try {
            CounterfeitWorkflow workflow = workflowClient.newWorkflowStub(
                    CounterfeitWorkflow.class,
                    WorkflowOptions.newBuilder()
                            .setTaskQueue("counterfeit_task_queue")
                            .setWorkflowId(recordId)
                            .build()
            );
            WorkflowInput workflowInput = new WorkflowInput();
            workflowInput.setRecordId(transaction.getRecordId());
            workflowInput.setStatus(transaction.getStatus());
            WorkflowExecution execution = WorkflowClient.start(workflow::triggerWorkflow, workflowInput, ActionUserType.MAKER);
            log.info("Workflow started for recordId: {} with WorkflowId: {}", recordId, execution.getWorkflowId());
            Map<String, Object> responseBody = new HashMap<>();
            responseBody.put(MESSAGE, "Transaction created successfully");
            responseBody.put(REQUEST_ID, transactionEntity.getRecordId());
            responseBody.put("pdfLink", pdfLink);
            return new ResponseEntity<>(responseBody, HttpStatus.CREATED);
        } catch (Exception e) {
            log.error("Failed to start workflow", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_STARTING_WORKFLOW")
                            .message("An unexpected error occurred while starting the workflow")
                            .build()))
                    .build();
        }
    }

    private void setNoteCount(Transaction transaction) {
        if (transaction.getNoteDetails().size() == 0) {
            transaction.setNoteCount(0);
        } else {
            transaction.setNoteCount(transaction.getNoteDetails().size());
        }
    }

    private List<Remarks> setUserRemarks(Transaction transaction, String userId) {

        List<Remarks> remarksList = new ArrayList<>();

        Remarks remarks = new Remarks();
        remarks.setUserType(transaction.getUserType());
        remarks.setUserId(userId);
        remarks.setRemarks(transaction.getUserRemarks().get(0).getRemarks());
        LocalDateTime now = LocalDateTime.now();
        remarks.setRemarksTimeStamp(now);

        remarksList.add(remarks);
        return remarksList;

    }

    public byte[] readPdfAsBytes(String transactionId, String type) {
        try {
            TransactionReportingEntity transactionReportingEntity = dbHelper.getTransactionReportingById(transactionId);
            TransactionReporting transactionReporting = convertReportingToDto(transactionReportingEntity);
            transactionReporting.setRecordId(transactionId);
            decryptTransactionReportingDetails(transactionReporting);
            byte[] pdfContent = pdf.generatePdf(transactionReporting, transactionId, type);
            if (pdfContent != null) {
                try {
                    java.nio.file.Files.write(Paths.get(pdfPath + transactionId + ".pdf"), pdfContent);
                    log.info("PDF saved successfully for recordId: {}", transactionId);
                } catch (IOException e) {
                    log.error("Error saving PDF for recordId {}", transactionId, e);
                }
                File file = new File(pdfPath + transactionId + ".pdf");
                if (!file.exists()) {
                    throw new PdfGenerationException("PDF file not found at: " + pdfPath + transactionId + ".pdf");
                }
                return Files.readAllBytes(file.toPath());
            } else {
                log.error("Failed to generate PDF for recordId {}", transactionId);
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("ERROR_GENERATING_PDF")
                                .message("Failed to generate PDF for transaction")
                                .build()))
                        .build();
            }
        } catch (Exception e) {
            log.error("Error reading PDF file", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_READING_PDF")
                            .message("An unexpected error occurred while reading the PDF file")
                            .build()))
                    .build();
        }
    }

    @Scheduled(cron = "0 0 0 * * ?")
    public void checkForTATBreach() {
        try {
            ResponseEntity<List<Transaction>> response = getTransactionsByStatus(SUBMITTED);

            if (response.getStatusCode() != HttpStatus.OK || response.getBody() == null || response.getBody().isEmpty()) {
                log.info("No transactions found with status" + SUBMITTED);
                return;
            }

            List<Transaction> submittedTransactions = response.getBody();
            updateTransactionsForTATBreach(submittedTransactions);

        } catch (Exception e) {
            log.error("Failed to check for TAT breaches", e);
        }
    }

    private void updateTransactionsForTATBreach(List<Transaction> submittedTransactions) {
        for (Transaction transactionDto : submittedTransactions) {
            try {
                LocalDateTime creationDate = transactionDto.getCreationDate();
                if (ChronoUnit.DAYS.between(creationDate, LocalDateTime.now()) > 10) {
                    transactionDto.setStatus("TAT Breached");
                    TransactionEntity updatedTransactionEntity = convertToEntity(transactionDto);
                    dbHelper.updateTransaction(updatedTransactionEntity);
                    log.info("Transaction with recordId {} has been updated to TAT Breached", transactionDto.getRecordId());
                }
            } catch (Exception e) {
                log.error("Unexpected error while processing transaction with recordId {}", transactionDto.getRecordId(), e);
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("ERROR_UPDATING_TRANSACTION")
                                .message("An unexpected error occurred while updating transaction with recordId: " + transactionDto.getRecordId())
                                .build()))
                        .build();
            }
        }
    }

    public ResponseEntity<Transaction> getTransactionById(String recordId, Integer version) {
        try {
            TransactionEntity transactionEntity = dbHelper.getTransactionById(recordId, version);
            if (transactionEntity == null) {
                log.warn("Transaction not found for Id : {}", recordId);
                throw new TransactionNotFoundException(recordId);
            }
            Transaction transactionDTO = convertToDto(transactionEntity);
            decryptTransactionDetails(transactionDTO);
            return new ResponseEntity<>(transactionDTO, HttpStatus.OK);
        } catch (TransactionNotFoundException e) {
            log.error(e.getMessage());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            log.error("Failed to fetch transaction", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTION")
                            .message("An unexpected error occurred while fetching the transaction with recordId: " + recordId)
                            .build()))
                    .build();
        }
    }

    public ResponseEntity<List<Transaction>> getAllTransactions() {
        try {
            List<TransactionEntity> transactionEntities = dbHelper.getAllTransactions();
            List<Transaction> transactions = transactionEntities.stream()
                    .map(this::convertToDto)
                    .toList();

            decryptTransactionDetailsForAll(transactions);

            log.info("Fetched {} transactions", transactions.size());
            return new ResponseEntity<>(transactions, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to fetch transactions", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTIONS")
                            .message("An unexpected error occurred while fetching all transactions")
                            .build()))
                    .build();
        }
    }

    private void decryptTransactionDetailsForAll(List<Transaction> transactions) {
        for (Transaction transaction : transactions) {
            try {
                decryptTransactionDetails(transaction);
            } catch (Exception e) {
                log.error("Failed to decrypt transaction details: {}", transaction.getRecordId(), e);
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("ERROR_DECRYPTING_TRANSACTION_DETAILS")
                                .message("Failed to decrypt transaction details for recordId: " + transaction.getRecordId())
                                .build()))
                        .build();
            }
        }
    }

    public ResponseEntity<List<Transaction>> getTransactionsByStatus(String status) {
        try {
            log.info("Fetching transactions with status: {}", status);

            List<TransactionEntity> allTransactions = dbHelper.getAllTransactions();

            List<TransactionEntity> filteredTransactions = allTransactions.stream()
                    .filter(transaction -> filterByStatus(transaction, status))
                    .toList();

            List<Transaction> transactionDtos = filteredTransactions.stream()
                    .map(this::convertToDto)
                    .toList();

            log.info("Fetched {} transactions with status: {}", transactionDtos.size(), status);
            return new ResponseEntity<>(transactionDtos, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Failed to fetch transactions by status: {}", status, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTIONS_BY_STATUS")
                            .message("An unexpected error occurred while fetching transactions by status: " + status)
                            .build()))
                    .build();
        }
    }

    public ResponseEntity<List<Transaction>> getTransactionsByBranch(String branchCode) throws TransactionFilterException {
        log.info("Filtering transactions for branchCode: {}", branchCode);
        try {
            List<Transaction> allTransactions = getAllTransactions().getBody();

            if (allTransactions != null && !allTransactions.isEmpty()) {
                List<Transaction> filteredTransactions = allTransactions.stream()
                        .filter(transaction -> branchCode.equals(transaction.getBranchDetails().getId()))
                        .toList();

                log.info("Filtered {} transactions for branchCode: {}", filteredTransactions.size(), branchCode);
                return ResponseEntity.ok(filteredTransactions);
            } else {
                log.warn("No transactions available to filter by branchCode");
                return ResponseEntity.ok(Collections.emptyList());
            }
        } catch (Exception e) {
            log.error("Error filtering transactions for branchCode: {}", branchCode, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILTERING_TRANSACTIONS_BY_BRANCH")
                            .message("Error filtering transactions for branchCode: " + branchCode)
                            .build()))
                    .build();
        }
    }

    public ResponseEntity<List<Transaction>> getTransactionsByMaker(String makerID) {
        log.info("Fetching transactions for makerID: {}", makerID);
        try {
            List<Transaction> allTransactions = getAllTransactions().getBody();

            if (allTransactions != null && !allTransactions.isEmpty()) {
                List<Transaction> filteredTransactions = allTransactions.stream()
                        .filter(transaction -> makerID.equals(transaction.getMaker().get(0).getId()))
                        .toList();

                log.info("Fetched {} transactions for the given maker", filteredTransactions.size());
                return ResponseEntity.ok(filteredTransactions);
            } else {
                log.warn("No transactions available to filter by makerID");
                return ResponseEntity.ok(Collections.emptyList());
            }
        } catch (Exception e) {
            log.error("Failed to fetch transactions for maker", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTIONS_BY_MAKER")
                            .message("Error fetching transactions for makerID: " + makerID)
                            .build()))
                    .build();
        }
    }

    private boolean filterByStatus(TransactionEntity transactionEntity, String status) {
        try {
            if (status == null || status.isEmpty()) {
                return true;
            }

            String transactionStatus = String.valueOf(transactionEntity.getTransactionData().get("status"));

            return status.equals(transactionStatus);
        } catch (Exception e) {
            log.error("Error filtering transaction by status: {}", status, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILTERING_BY_STATUS")
                            .message("Error filtering transaction by status: " + status)
                            .build()))
                    .build();
        }
    }
    private boolean filterByStatus(TransactionEntity transaction, List<String> status) {
        try {
            if (status == null || status.isEmpty()) {
                return true;
            }
            String transactionStatus = String.valueOf(transaction.getTransactionData().get("status"));
            return status.contains(transactionStatus);
        } catch (Exception e) {
            log.error("Error filtering transaction by status list: {}", status, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILTERING_BY_STATUS_LIST")
                            .message("Error filtering transaction by status list: " + status)
                            .build()))
                    .build();
        }
    }

    public ResponseEntity<List<Transaction>> getTransactionsWithFilters(List<String> status, List<Integer> denominations, Date fromDate, Date toDate) {
        try {
            log.info("Fetching transactions with filters - Status: {}, Denominations: {}, Date Range: {} to {}", status, denominations, fromDate, toDate);

            List<TransactionEntity> allTransactions = dbHelper.getAllTransactions();

            List<TransactionEntity> filteredTransactions = allTransactions.stream()
                    .filter(transaction ->
                            filterByStatus(transaction, status) &&
                                    filterByDenomination(transaction, denominations) &&
                                    filterByDateRange(transaction, fromDate, toDate)
                    )
                    .toList();

            List<Transaction> transactionDtos = filteredTransactions.stream()
                    .map(this::convertToDto)
                    .toList();

            for (Transaction transaction : transactionDtos) {
                decryptTransactionDetails(transaction);
            }

            log.info("Fetched {} transactions with applied filters", transactionDtos.size());
            return new ResponseEntity<>(transactionDtos, HttpStatus.OK);
        } catch (TransactionDecryptionException e) {
            log.error("Failed to decrypt transaction details", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_DECRYPTING_TRANSACTION_DETAILS")
                            .message("Failed to decrypt transaction details")
                            .build()))
                    .build();
        } catch (Exception e) {
            log.error("Failed to fetch transactions with filters", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTIONS_WITH_FILTERS")
                            .message("Failed to fetch transactions with filters")
                            .build()))
                    .build();
        }
    }

    public boolean filterByDenomination(TransactionEntity transaction, List<Integer> requestedDenominations) {
        try {
            Object notesData = transaction.getTransactionData().get("notes");

            log.info("Transaction ID: {}", transaction.getRecordId());
            log.info("Notes data type: {}", notesData != null ? notesData.getClass().getName() : "null");
            List<?> notesList = (List<?>) notesData;
            log.info("Transaction notes size: {}", notesList.size());

            boolean matchFound = notesList.stream().anyMatch(note -> {
                if (note instanceof Map) {
                    Map<?, ?> noteMap = (Map<?, ?>) note;
                    Object denominationObj = noteMap.get("denomination");

                    if (denominationObj instanceof Integer) {
                        return requestedDenominations.contains(denominationObj);
                    } else {
                        log.warn("Denomination value is not an Integer: {}", denominationObj);
                    }
                }
                return false;
            });

            log.info("Denomination filter match found for transaction ID {}: {}", transaction.getRecordId(), matchFound);
            return matchFound;

        } catch (Exception e) {
            log.error("Error filtering transaction by denominations: {}", requestedDenominations, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILTERING_BY_DENOMINATIONS")
                            .message("Error filtering transaction by denominations: " + requestedDenominations)
                            .build()))
                    .build();
        }
    }

    private boolean filterByDateRange(TransactionEntity transaction, Date fromDate, Date toDate) {
        try {
            if (fromDate == null && toDate == null) {
                return true;
            }
            String transactionDateStr = String.valueOf(transaction.getTransactionData().get("transactionDate"));
            Date transactionDate = parseDate(transactionDateStr);

            if (transactionDate == null) {
                return false;
            }

            boolean isAfterFromDate = (fromDate == null || !transactionDate.before(fromDate));
            boolean isBeforeToDate = (toDate == null || !transactionDate.after(toDate));
            return isAfterFromDate && isBeforeToDate;
        } catch (Exception e) {
            log.error("Error filtering transaction by date range: {} to {}", fromDate, toDate, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILTERING_BY_DATE_RANGE")
                            .message("Error filtering transaction by date range")
                            .build()))
                    .build();
        }
    }

    public Date parseDate(String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
            return sdf.parse(dateString);
        } catch (ParseException e) {
            log.error("Error parsing date: {}", dateString, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_PARSING_DATE")
                            .message("Error parsing date")
                            .build()))
                    .build();
        }
    }

    public ResponseEntity<List<Integer>> getTotalFIRPerMonth(String branchCode) {
        log.info("Fetching transactions for branch: {}", branchCode);
        try {
            List<Transaction> transactionEntities = getAllTransactions().getBody();

            if (transactionEntities == null || transactionEntities.isEmpty()) {
                log.warn("No transactions found for branch: {}", branchCode);
                return ResponseEntity.ok(Arrays.asList(0, 0));
            }

            List<Transaction> filteredTransactions = transactionEntities.stream()
                    .filter(transaction -> branchCode.equals(transaction.getAccountNumber()))
                    .collect(Collectors.toList());

            List<Transaction> lastMonthFIRs = getLastMonthFIRs(filteredTransactions);

            List<Integer> counts = lastMonthFIRs.stream()
                    .map(Transaction::getNoteCount)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());

            int additionalCount = counts.stream()
                    .filter(count -> count > 4)
                    .mapToInt(Integer::intValue)
                    .sum();

            log.info("Total FIR Count Notes List: {}", counts);

            int totalFIR = calculateTotalFIRCount(counts);

            List<Integer> countOfNotesFIRs = Arrays.asList(totalFIR, additionalCount);

            log.info("Result: {}", countOfNotesFIRs);
            return ResponseEntity.ok(countOfNotesFIRs);

        } catch (Exception e) {
            log.error("Failed to fetch transactions: {}", e.getMessage(), e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_TRANSACTIONS")
                            .message("Failed to fetch transactions")
                            .build()))
                    .build();
        }
    }

    public List<Transaction> getLastMonthFIRs(List<Transaction> transactionList) {
        List<Transaction> totalFIRs = new ArrayList<>();
        LocalDate currentDate = LocalDate.now();

        LocalDate firstDayOfLastMonth = currentDate.minusMonths(1).withDayOfMonth(1);
        LocalDate firstDayOfCurrentMonth = currentDate.withDayOfMonth(1);

        try {
            transactionList.stream()
                    .filter(transaction ->
                            "Approved".equals(transaction.getStatus()) && transaction.getNoteDetails() != null
                    )
                    .flatMap(transaction -> transaction.getNoteDetails().stream()
                            .filter(note -> note.getPoliceReportingDate() != null)
                            .map(note -> new AbstractMap.SimpleEntry<>(transaction, note))
                    )
                    .filter(entry -> {
                        LocalDateTime transactionDate = entry.getKey().getCreationDate();
                        return transactionDate != null &&
                                transactionDate.isAfter(firstDayOfLastMonth.atStartOfDay()) &&
                                transactionDate.isBefore(firstDayOfCurrentMonth.atStartOfDay());
                    })
                    .map(Map.Entry::getKey)
                    .distinct()
                    .forEach(totalFIRs::add);
        } catch (Exception e) {
            log.error("Error fetching last month FIRs", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FETCHING_LAST_MONTH_FIRS")
                            .message("Error fetching last month FIRs")
                            .build()))
                    .build();
        }

        return totalFIRs;
    }

    private int calculateTotalFIRCount(List<Integer> counts) {
        int totalFIRCount = 0;

        for (int count : counts) {
            if (count > 5) {
                totalFIRCount++;
            }
        }

        return totalFIRCount;
    }

    public ResponseEntity<ApproveTransaction200Response> approveTransaction(
            String recordId, String checkerId, String checkerName, Transaction updatedTransaction) {
        try {
            Integer version = updatedTransaction.getVersion();
            TransactionEntity transactionEntity = dbHelper.getTransactionById(recordId, version);
            validateTransactionEntity(transactionEntity, recordId);

            Transaction transactionData = convertToDto(transactionEntity);
            validateApprovalConditions(transactionData, updatedTransaction, recordId);

            populateApprovalDetails(transactionData, updatedTransaction, checkerId, checkerName);

            TransactionEntity updatedTransactionEntity = convertToEntity(transactionData);
            updatedTransactionEntity.setRecordId(recordId);
            updatedTransactionEntity.setVersion(version + 1);
            dbHelper.updateTransaction(updatedTransactionEntity);

            updateWorkflowStatus(recordId, APPROVED);

            log.info("Transaction approved and updated successfully: {}", recordId);

            ApproveTransaction200Response response = new ApproveTransaction200Response()
                    .message("Transaction approved successfully");

            return ResponseEntity.ok(response);
        } catch (TransactionNotFoundException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ApproveTransaction200Response()
                            .message(TRANSACTION_NOT_FOUND_MESSAGE + recordId));
        } catch (InvalidTransactionStatusException | ApprovalRequiredFieldsException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ApproveTransaction200Response().message(e.getMessage()));
        } catch (Exception e) {
            log.error("Unexpected error while approving transaction: {}", recordId, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_APPROVING_TRANSACTION")
                            .message("Failed to approve transaction")
                            .build()))
                    .build();
        }
    }

    private void updateWorkflowStatus(String recordId, String status) {
//        WorkflowClient workflowClient = workflowClient;
        try {
            // Removed workflow stub creation and direct use for workflow calls
            CounterfeitWorkflow workflow = workflowClient.newWorkflowStub(
                    CounterfeitWorkflow.class,
                    recordId
            );
//            workflow.updateStatus(status);
            log.info("Workflow status updated to '{}' for recordId: {}", status, recordId);
        } catch (Exception e) {
            log.error("Failed to update workflow status for recordId: {}", recordId, e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("WORKFLOW_NOT_UPDATED")
                            .message("Failed to update workflow status")
                            .build()))
                    .build();
        }
    }

    private void validateTransactionEntity(TransactionEntity transactionEntity, String recordId) {
        if (transactionEntity == null) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("TRANSACTION_NOT_FOUND")
                            .message("Transaction Entity not found")
                            .build()))
                    .build();
        }
    }

        private void validateApprovalConditions(Transaction transactionData, Transaction updatedTransaction, String recordId) {
            String transactionStatus = transactionData.getStatus();
            if (!SUBMITTED.equals(transactionStatus)) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("INVALID_TRANSACTION_STATUS")
                                .message("Transaction status is not SUBMITTED for recordId: " + recordId)
                                .build()))
                        .build();
            }
            if (updatedTransaction.getNoteCount() > 4 && (updatedTransaction.getFirDate() == null || updatedTransaction.getFirNumber() == null || updatedTransaction.getFirPath() == null)) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("APPROVAL_REQUIRED_FIELDS_MISSING")
                                .message("Transaction cannot be approved without FIR details for recordId: " + recordId)
                                .build()))
                        .build();
            }
        }

    private void populateApprovalDetails(Transaction transactionData, Transaction updatedTransaction, String checkerId, String checkerName) {
        try {
            if (transactionData.getChecker() == null || transactionData.getChecker().isEmpty()) {
                Activity checker = new Activity();
                checker.setId(checkerId);
                checker.setName(checkerName);
                transactionData.setChecker(List.of(checker));
            }
            transactionData.setUserAction("APPROVE");
            transactionData.setUserType("CHECKER");

            transactionData.getUserRemarks().addAll(setUserRemarks(transactionData, checkerId));

            LocalDateTime now = LocalDateTime.now();
            transactionData.setCheckerApprovalDate(now);

            transactionData.setStatus(APPROVED);
            transactionData.setFirDate(updatedTransaction.getFirDate());
            transactionData.setFirNumber(updatedTransaction.getFirNumber());
            transactionData.setFirPath(updatedTransaction.getFirPath());
            transactionData.setUpdatedTime(updatedTransaction.getCheckerApprovalDate());
        } catch (Exception e) {
            log.error("Failed to populate transaction approval details", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_POPULATING_APPROVAL_DETAILS")
                            .message("Failed to populate transaction approval details")
                            .build()))
                    .build();
        }
    }

    private ResponseEntity<Map<String, Object>> buildApprovalResponse(String recordId) {
        Map<String, Object> responseBody = new HashMap<>();
        responseBody.put(REQUEST_ID, recordId);
        responseBody.put(MESSAGE, "Transaction approved successfully");
        return ResponseEntity.ok(responseBody);
    }

    public ResponseEntity<RejectTransaction200Response> rejectTransaction(String recordId, Integer version, String remarks, String checkerId, String checkerName) {
        try {
            TransactionEntity transactionEntity = dbHelper.getTransactionById(recordId, version);
            if (transactionEntity == null) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("TRANSACTION_NOT_FOUND")
                                .message("Transaction not found")
                                .build()))
                        .build();
            }

            Transaction transactionData = convertToDto(transactionEntity);
            if (transactionData.getCheckerRejectedDate() == null) {
                LocalDateTime now = LocalDateTime.now();
                transactionData.setCheckerRejectedDate(now);
            }

            if (remarks == null || remarks.isEmpty()) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("CHECKER_REMARKS_MISSING")
                                .message("checker remarks must be provided for rejection")
                                .build()))
                        .build();
            }

            String transactionStatus = transactionData.getStatus();
            if (!SUBMITTED.equals(transactionStatus)) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("INVALID_TRANSACTION_STATUS")
                                .message("Transaction status is not SUBMITTED for recordId: " + recordId)
                                .build()))
                        .build();
            }

            transactionData.setStatus(REJECTED);
            transactionData.setUserType("CHECKER");
            transactionData.setUserAction("REJECT");
            transactionData.setChecker(List.of(new Activity(checkerId, checkerName)));
            transactionData.setUpdatedTime(transactionData.getCheckerRejectedDate());

            transactionData.getUserRemarks().addAll(setUserRemarks(transactionData, checkerId));

            decryptTransactionDetails(transactionData);

            String auditTransactionData = deepCopyTransaction(transactionData);

            Audit olderVersion = new Audit();
            LocalDateTime now = LocalDateTime.now();
            Date currentDate = Date.from(now.atZone(ZoneId.systemDefault()).toInstant());
            olderVersion.setDate(currentDate);
            olderVersion.setData(List.of(auditTransactionData));

            AuditVersion auditVersion = new AuditVersion();
            auditVersion.setOlderVersion(List.of(olderVersion));

            transactionData.setAuditTrail(auditVersion);

            encryptTransactionDetails(transactionData);
            transactionEntity = convertToEntity(transactionData);

            transactionEntity.setRecordId(recordId);
            transactionEntity.setVersion(version++);
            dbHelper.updateTransaction(transactionEntity);

            CounterfeitWorkflow workflow = workflowClient.newWorkflowStub(
                    CounterfeitWorkflow.class, recordId);
            //workflow.checkerResponse(REJECTED);

            log.info("Transaction rejected and workflow updated: {}", recordId);

            return ResponseEntity.ok(new RejectTransaction200Response().message("Transaction rejected successfully"));

        } catch (Exception e) {
            log.error("Failed to reject transaction", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_REJECTING_TRANSACTION")
                            .message("Failed to reject transaction")
                            .build()))
                    .build();
        }
    }


    private String deepCopyTransaction(Transaction transaction) {
        String json = ObjectMapperUtil.toJson(transaction);

        if (json == null) {
            log.error("Failed to create a deep copy of the transaction for audit: Conversion to JSON returned null");
            return null;
        }

        Transaction copiedTransaction = ObjectMapperUtil.fromJson(json, Transaction.class);
        if (copiedTransaction == null) {
            log.error("Failed to deserialize the transaction from JSON after deep copy");
            return null;
        }

        return json;
    }

    private boolean validateTransactionFields(Transaction transactionData, List<Problem> problems) {

        if (transactionData == null) {
            problems.add(Problem.builder()
                    .code("TRANSACTION_NULL")
                    .message("Transaction data is null")
                    .build());
            return false;
        }

        String transactionType = transactionData.getTransactionType();
        String transactionTypeLower = transactionType != null ? transactionType.toLowerCase() : "";

        switch (transactionTypeLower) {
            case "account holder":
                return transactionData.getAccountNumber() != null &&
                        transactionData.getCustomerName() != null &&
                        transactionData.getCustomerNumber() != null &&
                        transactionData.getCustomerAddress() != null &&
                        transactionData.getAtmNumber() != null &&
                        transactionData.getNoteDetails() != null && !transactionData.getNoteDetails().isEmpty();


            case "crm":
                return transactionData.getVendorName() != null &&
                        transactionData.getCrmId() != null &&
                        transactionData.getNoteDetails() != null && !transactionData.getNoteDetails().isEmpty();

            case "walk-in customer":
                return transactionData.getCustomerName() != null &&
                        transactionData.getCustomerNumber() != null &&
                        transactionData.getAtmNumber() != null &&
                        transactionData.getCustomerAddress() != null &&
                        transactionData.getNoteDetails() != null && !transactionData.getNoteDetails().isEmpty();

            case "surprise verification", "currency chest":
                return transactionData.getCustomerName() != null &&
                        transactionData.getCustomerNumber() != null &&
                        transactionData.getCustomerAddress() != null &&
                        transactionData.getNoteDetails() != null && !transactionData.getNoteDetails().isEmpty();

            default:
                problems.add(Problem.builder()
                        .code("UNKNOWN_TRANSACTION_TYPE")
                        .message("Unknown transaction type: " + transactionType)
                        .build());
                return false;
        }
    }

    public ResponseEntity<AddPoliceReportingDetails200Response> addPoliceReportingDetails(
            String recordId,
            Integer version,
            String makerId,
            String makerName,
            Transaction updatedTransaction) {

        try {
            TransactionEntity existingTransactionEntity = dbHelper.getTransactionById(recordId, version);
            validateTransaction(existingTransactionEntity, recordId);

            Transaction existingTransaction = convertToDto(existingTransactionEntity);
            if (existingTransaction == null) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("TRANSACTION_DATA_NOT_FOUND")
                                .message("Transaction data not found")
                                .build()))
                        .build();
            }

            if (!isTransactionApproved(existingTransaction)) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("TRANSACTION_NOT_APPROVED")
                                .message("Transaction not approved yet")
                                .build()))
                        .build();
            }

            updateTransactionDetails(existingTransaction, makerId, makerName, updatedTransaction);
            TransactionEntity updatedTransactionEntity = convertToEntity(existingTransaction);
            updatedTransactionEntity.setRecordId(recordId);
            dbHelper.updateTransaction(updatedTransactionEntity);

            updateWorkflowStatus(recordId, "PoliceDetailsFilled");

            AddPoliceReportingDetails200Response successResponse = new AddPoliceReportingDetails200Response()
                    .message("Police reporting details added successfully");

            return ResponseEntity.ok(successResponse);

        } catch (TransactionNotFoundException e) {
            log.error(e.getMessage());
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("TRANSACTION_NOT_FOUND")
                            .message(TRANSACTION_NOT_FOUND_MESSAGE + recordId)
                            .build()))
                    .build();
        } catch (Exception e) {
            log.error("Failed to fill police report details", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_FILLING_POLICE_REPORT")
                            .message("Failed to fill police report details")
                            .build()))
                    .build();
        }
    }

    private void validateTransaction(TransactionEntity transactionEntity, String recordId) {
        if (transactionEntity == null) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("TRANSACTION_NOT_FOUND")
                            .message("Transaction not found for recordId: " + recordId)
                            .build()))
                    .build();
        }
    }

    private boolean isTransactionApproved(Transaction transaction) {
        return APPROVED.equalsIgnoreCase(transaction.getStatus());
    }

    private void updateTransactionDetails(Transaction existingTransaction, String makerId, String makerName, Transaction updatedTransaction) {
        try {
            Activity makerActivity = new Activity();
            makerActivity.setId(makerId);
            makerActivity.setName(makerName);
            existingTransaction.getMaker().add(makerActivity);
            existingTransaction.getUserRemarks().addAll(updatedTransaction.getUserRemarks());
            existingTransaction.setUserType("MAKER");
            existingTransaction.getUserRemarks().addAll(setUserRemarks(existingTransaction, makerId));

            for (Note existingNote : existingTransaction.getNoteDetails()) {
                for (Note updatedNote : updatedTransaction.getNoteDetails()) {
                    if (existingNote.getNoteId().equals(updatedNote.getNoteId())) {
                        updateNoteDates(existingNote, updatedNote, existingTransaction);
                    }
                }
            }
        } catch (Exception e) {
            log.error("Failed to update transaction details", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_UPDATING_TRANSACTION_DETAILS")
                            .message("Failed to update transaction details")
                            .build()))
                    .build();
        }
    }

    private void updateNoteDates(Note existingNote, Note updatedNote, Transaction existingTransaction) {
        if (existingTransaction.getNoteDetails().size() < 5) {
            existingNote.setPoliceReportingDate(updatedNote.getPoliceReportingDate());
        } else {
            existingNote.setPoliceReportingDate(existingTransaction.getFirDate());
        }

        if (existingNote.getPoliceReportingDate() != null) {
            existingNote.setReturnFromPoliceDate(updatedNote.getReturnFromPoliceDate());
            if (existingNote.getReturnFromPoliceDate() != null) {
                existingNote.setRbiSubmissionDate(calculateRbiSubmissionDate(existingNote.getReturnFromPoliceDate()));
            }
        }
    }


    public ResponseEntity<UpdateTransaction200Response> updateTransaction(
            String recordId, String makerId, String makerName, Transaction updatedTransaction) {
        try {
            Integer version = updatedTransaction.getVersion();
            TransactionEntity existingTransactionEntity = dbHelper.getTransactionById(recordId, version);
            if (existingTransactionEntity == null) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("TRANSACTION_NOT_FOUND")
                                .message(TRANSACTION_NOT_FOUND_MESSAGE + recordId)
                                .build()))
                        .build();
            }

            Transaction existingTransactionDto = convertToDto(existingTransactionEntity);

            boolean isMakerValid = existingTransactionDto.getMaker().stream()
                    .anyMatch(maker -> makerId.equals(maker.getId()) && makerName.equals(maker.getName()));

            if (!isMakerValid) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("INVALID_MAKER")
                                .message("Maker ID and Maker Name do not match with the existing transaction.")
                                .build()))
                        .build();
            }

            if (!REJECTED.equals(existingTransactionDto.getStatus())) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("INVALID_TRANSACTION_STATUS")
                                .message("Transaction status must be 'Rejected' before updating.")
                                .build()))
                        .build();
            }

            Transaction existingTransaction = convertToDto(existingTransactionEntity);
            if (existingTransaction == null) {
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("TRANSACTION_DESERIALIZATION_ERROR")
                                .message("Failed to deserialize transaction data for recordId: " + recordId)
                                .build()))
                        .build();
            }

            AuditVersion auditTrail = existingTransaction.getAuditTrail();
            if (auditTrail == null) {
                auditTrail = new AuditVersion();
            }

            if (auditTrail.getOlderVersion() == null) {
                auditTrail.setOlderVersion(new ArrayList<>());
            }
            if (auditTrail.getCurrentVersion() == null) {
                auditTrail.setCurrentVersion(new ArrayList<>());
            }

            String updatedTransactionSnapshot = deepCopyTransaction(updatedTransaction);
            auditTrail.getCurrentVersion().add(new Audit(new Date(), List.of(updatedTransactionSnapshot)));

            existingTransaction.setUserAction("SUBMIT");
            existingTransaction.setUserType("MAKER");
            existingTransaction.getUserRemarks().addAll(setUserRemarks(updatedTransaction, makerId));
            existingTransaction.getMaker().addAll(updatedTransaction.getMaker());
            existingTransaction.setNoteDetails(updatedTransaction.getNoteDetails());
            existingTransaction.setStatus(RE_SUBMITTED);
            existingTransaction.setUpdatedTime(LocalDateTime.now());

            TransactionEntity updatedEntity = convertToEntity(existingTransaction);
            updatedEntity.setRecordId(recordId);
            updatedEntity.setVersion(version++);
            dbHelper.updateTransaction(updatedEntity);

            CounterfeitWorkflow workflow = workflowClient.newWorkflowStub(CounterfeitWorkflow.class, recordId);
            // workflow.updateStatus(RE_SUBMITTED);
            log.info("Transaction re-submitted successfully and workflow updated: {}", recordId);

            UpdateTransaction200Response successResponse = new UpdateTransaction200Response()
                    .message("Transaction updated successfully");
            return ResponseEntity.ok(successResponse);

        } catch (ManagedException e) {
            log.error(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new UpdateTransaction200Response().message(e.getMessage()));
        } catch (Exception e) {
            log.error("Failed to update transaction", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_UPDATING_TRANSACTION")
                            .message("Failed to update transaction")
                            .build()))
                    .build();
        }
    }

    private TransactionEntity convertToEntity(Transaction transaction) {
        TransactionEntity transactionEntity = new TransactionEntity();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            Map<String, Transaction> transactionData = objectMapper.convertValue(transaction, Map.class);

            transactionData.remove(REQUEST_ID);
            transactionData.entrySet().removeIf(entry -> entry.getValue() == null);

            transactionEntity.setTransactionData(transactionData);

        } catch (IllegalArgumentException e) {
            log.error("Failed to convert transaction to entity: {}", transaction.getRecordId(), e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_CONVERTING_TRANSACTION_TO_ENTITY")
                            .message("Failed to convert transaction to entity")
                            .build()))
                    .build();
        }

        return transactionEntity;
    }

    private TransactionReportingEntity convertToReportEntity(TransactionReporting transactionReporting) {
        TransactionReportingEntity transactionReportingEntity = new TransactionReportingEntity();

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            Map<String, TransactionReporting> transactionData = objectMapper.convertValue(transactionReporting, Map.class);

            transactionData.remove(REQUEST_ID);
            transactionData.entrySet().removeIf(entry -> entry.getValue() == null);

            transactionReportingEntity.setTransactionReportingData(transactionData);

        } catch (IllegalArgumentException e) {
            log.error("Failed to convert transaction reporting to entity", e);
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ERROR_CONVERTING_REPORT_TO_ENTITY")
                            .message("Failed to convert transaction reporting to entity")
                            .build()))
                    .build();
        }

        return transactionReportingEntity;
    }

    private Transaction convertToDto(TransactionEntity entity) {
        if (entity == null) {
            throw new IllegalArgumentException("TransactionEntity cannot be null");
        }

        Transaction transaction = new Transaction();

        if (entity.getTransactionData() != null) {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);

            try {
                transaction = objectMapper.convertValue(entity.getTransactionData(), Transaction.class);
                transaction.setRecordId(entity.getRecordId());
            } catch (IllegalArgumentException e) {
                log.error("Error converting TransactionEntity to Transaction: {}", e.getMessage());
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("ERROR_CONVERTING_ENTITY_TO_DTO")
                                .message("Error converting TransactionEntity to Transaction")
                                .build()))
                        .build();
            }
        }
        return transaction;
    }

    private TransactionReporting convertReportingToDto(TransactionReportingEntity entity) {
        if (entity == null) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ENTITY_NULL_ERROR")
                            .message("TransactionReportingEntity cannot be null")
                            .build()))
                    .build();
        }
        TransactionReporting transactionReporting = new TransactionReporting();

        if (entity.getTransactionReportingData() != null) {
            ObjectMapper objectMapper = new ObjectMapper();

            objectMapper.registerModule(new JavaTimeModule());

            objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
            try {
                transactionReporting = objectMapper.convertValue(entity.getTransactionReportingData(), TransactionReporting.class);
            } catch (IllegalArgumentException e) {
                log.error("Error converting TransactionReportingEntity to TransactionReporting: {}", e.getMessage());
                throw ManagedException.builder()
                        .problems(List.of(Problem.builder()
                                .code("CONVERSION_ERROR")
                                .message("Error converting TransactionReportingEntity to TransactionReporting")
                                .build()))
                        .build();
            }
        }
        return transactionReporting;
    }

    private void encryptTransactionDetails(Transaction transaction) throws Exception {
        try {
            if (transaction.getAccountNumber() != null) {
                transaction.setAccountNumber(encrypt(transaction.getAccountNumber()));
            }

            if (transaction.getCustomerNumber() != null) {
                transaction.setCustomerNumber(encrypt(transaction.getCustomerNumber()));
            }

            if (transaction.getCustomerName() != null) {
                transaction.setCustomerName(encrypt(transaction.getCustomerName()));
            }
        } catch (Exception e) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("ENCRYPTION_ERROR")
                            .message("Failed to encrypt transaction details")
                            .build()))
                    .build();
        }
    }

    private void decryptTransactionDetails(Transaction transaction) throws Exception {
        try {
            if (transaction.getAccountNumber() != null) {
                transaction.setAccountNumber(decrypt(transaction.getAccountNumber()));
            }

            if (transaction.getCustomerNumber() != null) {
                transaction.setCustomerNumber(decrypt(transaction.getCustomerNumber()));
            }

            if (transaction.getCustomerName() != null) {
                transaction.setCustomerName(decrypt(transaction.getCustomerName()));
            }
        } catch (Exception e) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("DECRYPTION_ERROR")
                            .message("Failed to decrypt transaction details")
                            .build()))
                    .build();
        }
    }

    private void decryptTransactionReportingDetails(TransactionReporting transaction) throws Exception {
        try {
            if (transaction.getCustomerNumber() != null) {
                transaction.setCustomerNumber(decrypt(transaction.getCustomerNumber()));
            }

            if (transaction.getCustomerName() != null) {
                transaction.setCustomerName(decrypt(transaction.getCustomerName()));
            }
        } catch (Exception e) {
            throw ManagedException.builder()
                    .problems(List.of(Problem.builder()
                            .code("DECRYPTION_ERROR")
                            .message("Failed to decrypt transaction reporting details")
                            .build()))
                    .build();
        }
    }

    private Date calculateRbiSubmissionDate(Date returnFromPoliceDate) {

        LocalDate returnFromPoliceLocalDate = returnFromPoliceDate.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        LocalDate rbiSubmissionDateLocalDate = returnFromPoliceLocalDate.plusYears(3);

        if (returnFromPoliceLocalDate.getMonth() == java.time.Month.FEBRUARY &&
                returnFromPoliceLocalDate.getDayOfMonth() == 29 &&
                !YearMonth.from(rbiSubmissionDateLocalDate).isLeapYear()) {

            rbiSubmissionDateLocalDate = rbiSubmissionDateLocalDate.minusDays(1);
        }

        LocalDateTime rbiSubmissionDateLocalDateTime = rbiSubmissionDateLocalDate.atStartOfDay();

        return Date.from(rbiSubmissionDateLocalDateTime.atZone(ZoneId.systemDefault()).toInstant());
    }

    public String generateRequestId() {
        LocalDateTime now = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("ddMMyy");
        String formattedDate = now.format(formatter).replace("-", "");

        String timestampSuffix = String.valueOf(System.currentTimeMillis() % 10000);

        String recordId = BRANCH_CODE + formattedDate + timestampSuffix;

        log.info("Generated recordId: " + recordId);

        return recordId;
    }

    public String generateTransactionId(Transaction transaction) {

        String branchId = transaction.getBranchDetails().getId();
        String register = transaction.getRegisterType();
        String transactionId = branchId + "" + register;

        return transactionId;
    }

}