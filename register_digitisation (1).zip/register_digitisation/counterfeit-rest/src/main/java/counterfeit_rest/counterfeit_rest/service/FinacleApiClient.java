package counterfeit_rest.counterfeit_rest.service;

import feign.Headers;
import feign.RequestLine;

public interface FinacleApiClient {

    @RequestLine("POST")
    @Headers("Content-Type: application/xml")
    String finacleRestCall(String requestBody);
}
