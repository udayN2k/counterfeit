package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.api;

import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.FIR;
import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.Transaction;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import org.springframework.web.context.request.NativeWebRequest;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Validated
@Tag(name = "transactions", description = "The transactions API")
public interface TransactionsApi {

    default Optional<NativeWebRequest> getRequest() {
        return Optional.empty();
    }

    @Operation(
            operationId = "createTransaction",
            summary = "Create a new transaction",
            responses = {
                    @ApiResponse(responseCode = "201", description = "Transaction created successfully", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = Transaction.class))
                    }),
                    @ApiResponse(responseCode = "400", description = "Invalid input data")
            }
    )
    @PostMapping(
            value = "/create",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    ResponseEntity<Map<String, Object>> createTransaction(
            @Valid @RequestBody Transaction transaction,
            @RequestParam String makerId,
            @RequestParam String branchCode,
            @RequestParam String makerName
    );

    @Operation(
            operationId = "getTransactionById",
            summary = "Get a transaction by ID",
            responses = {
                    @ApiResponse(responseCode = "200", description = "A transaction object", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = Transaction.class))
                    }),
                    @ApiResponse(responseCode = "404", description = "Transaction not found")
            }
    )
    @GetMapping(value = "/getById/{recordId}/{version}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Transaction> getTransactionById(@PathVariable String recordId,@PathVariable Integer version);

    @Operation(
            operationId = "getAllTransactions",
            summary = "Retrieve all transactions",
            responses = {
                    @ApiResponse(responseCode = "200", description = "A list of transactions", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Transaction.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch all transactions")
            }
    )
    @GetMapping(value = "/getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<Transaction>> getAllTransactions();

    @Operation(
            operationId = "getTransactionsByMaker",
            summary = "Retrieve transactions by maker ID",
            responses = {
                    @ApiResponse(responseCode = "200", description = "A list of transactions", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Transaction.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch transactions for maker")
            }
    )
    @GetMapping(value = "/getMakerTransactions", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<Transaction>> getTransactionsByMaker(
            @RequestParam String makerID
    );

    @Operation(
            operationId = "getTransactionsByBranch",
            summary = "Retrieve transactions by branch code",
            responses = {
                    @ApiResponse(responseCode = "200", description = "A list of transactions", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Transaction.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch transactions for branch")
            }
    )
    @GetMapping(value = "/getBranchTransactions", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<Transaction>> getTransactionsByBranch(
            @RequestParam String branchCode
    );

    @Operation(
            operationId = "approveTransaction",
            summary = "Approve a transaction",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Transaction approved successfully"),
                    @ApiResponse(responseCode = "500", description = "Failed to approve transaction")
            }
    )
    @PutMapping(value = "/approve/{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Map<String, Object>> approveTransaction(
            @PathVariable String requestId,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @Valid @RequestBody Transaction updatedTransaction
    );

    @Operation(
            operationId = "rejectTransaction",
            summary = "Reject a transaction",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Transaction rejected successfully"),
                    @ApiResponse(responseCode = "500", description = "Failed to reject transaction")
            }
    )
    @PutMapping(value = "/reject/{requestId}/{version}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Map<String, Object>> rejectTransaction(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String remarks,
            @RequestParam String checkerId,
            @RequestParam String checkerName
    );

    @Operation(
            operationId = "updateTransaction",
            summary = "Update a transaction",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Transaction updated successfully"),
                    @ApiResponse(responseCode = "500", description = "Failed to update transaction")
            }
    )
    @PutMapping(value = "/update/{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Map<String, Object>> updateTransaction(
            @PathVariable String requestId,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @Valid @RequestBody Transaction transaction
    );

    @Operation(
            operationId = "addPoliceReportingDetails",
            summary = "Add police reporting details to a transaction",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Details added successfully"),
                    @ApiResponse(responseCode = "500", description = "Failed to add details")
            }
    )
    @PutMapping(value = "addReportingDetails/{requestId}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Map<String, Object>> addPoliceReportingDetails(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @Valid @RequestBody Transaction transaction
    );

    @Operation(
            operationId = "getTransactionsWithFilters",
            summary = "Retrieve transactions with filters",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Transactions fetched successfully", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Transaction.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch transactions")
            }
    )
    @GetMapping(value = "/filter", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<Transaction>> getTransactionsWithFilters(
            @RequestParam(value = "status", required = false) List<String> status,
            @RequestParam(value = "denominations", required = false) List<Integer> denominations,
            @RequestParam(value = "fromDate", required = false) @Schema(type = "string", format = "date") Date fromDate,
            @RequestParam(value = "toDate", required = false) @Schema(type = "string", format = "date") Date toDate
    );

    @Operation(
            operationId = "getFIRById",
            summary = "Get FIR by ID",
            responses = {
                    @ApiResponse(responseCode = "200", description = "FIR found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = FIR.class))
                    }),
                    @ApiResponse(responseCode = "404", description = "FIR not found")
            }
    )
    @GetMapping(value = "/fir/{requestId}/{branchCode}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<FIR> getFIRById(
            @PathVariable String requestId,
            @PathVariable String branchCode
    );

    @Operation(
            operationId = "findByBranchCode",
            summary = "Find FIRs by branch code",
            responses = {
                    @ApiResponse(responseCode = "200", description = "List of FIRs found", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = FIR.class)))
                    }),
                    @ApiResponse(responseCode = "404", description = "No FIRs found for branch code")
            }
    )
    @GetMapping(value = "/findFir/branch/{branchCode}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<FIR>> findByBranchCode(
            @PathVariable String branchCode
    );

    @Operation(
            operationId = "getAllFIRs",
            summary = "Get all FIRs",
            responses = {
                    @ApiResponse(responseCode = "200", description = "List of all FIRs", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = FIR.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch FIRs")
            }
    )
    @GetMapping(value = "/fir/getAll", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<FIR>> getAllFIR();

    @Operation(
            operationId = "getPdfAsBytes",
            summary = "Get PDF file as bytes",
            responses = {
                    @ApiResponse(responseCode = "200", description = "PDF file returned as bytes", content = {
                            @Content(mediaType = "application/pdf")
                    }),
                    @ApiResponse(responseCode = "404", description = "PDF file not found"),
                    @ApiResponse(responseCode = "500", description = "Internal server error")
            }
    )
    @GetMapping(value = "/pdf/{requestId}", produces = MediaType.APPLICATION_PDF_VALUE)
    ResponseEntity<byte[]> getPdfAsBytes(@PathVariable String requestId, @RequestParam String copyType);

    @Operation(
            operationId = "createFIR",
            summary = "Create a new FIR",
            responses = {
                    @ApiResponse(responseCode = "201", description = "FIR created successfully", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = FIR.class))
                    }),
                    @ApiResponse(responseCode = "400", description = "Invalid input data")
            }
    )
    @PostMapping(
            value = "/fir/create",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    ResponseEntity<Map<String, Object>> createFIR(
            @RequestBody FIR fir,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @RequestParam String branchCode
    );

    @Operation(
            operationId = "getLastMonthFIRs",
            summary = "Retrieve FIRs by branch code",
            responses = {
                    @ApiResponse(responseCode = "200", description = "List of FIRs found", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = FIR.class)))
                    }),
                    @ApiResponse(responseCode = "404", description = "FIR not found"),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch FIRs")
            }
    )
    @GetMapping(value = "/pervious/{branchCode}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<FIR>> getLastMonthFIRs(@PathVariable String branchCode);

    // Get Total FIRs Per Month
    @Operation(
            operationId = "getTotalFIRPerMonth",
            summary = "Get total number of FIRs per month",
            parameters = {
                    @Parameter(name = "branchCode", description = "The code of the branch for which to get the FIR counts", required = true, schema = @Schema(type = "string"))
            },
            responses = {
                    @ApiResponse(responseCode = "200", description = "List of total FIR counts per month", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(type = "integer")))
                    }),
                    @ApiResponse(responseCode = "404", description = "No FIRs found"),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch FIR data")
            }
    )
    @GetMapping(value = "/count", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<Integer>> getTotalFIRPerMonth(@RequestParam String branchCode);

    @Operation(
            operationId="getFilters",
            summary="Retrieve transactions with filters",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Transactions fetched successfully", content = {
                            @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = Transaction.class)))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch transactions")
            }
    )
    @GetMapping(value = "/sorting", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<List<FIR>> getFilters(@RequestParam(value = "fromDate", required = false) @Schema(type = "string", format = "date") Date fromDate,
                                         @RequestParam(value = "toDate", required = false) @Schema(type = "string", format = "date") Date toDate);

    @Operation(
            operationId = "getAccountDetails",
            summary = "Get account details by account number",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Account details found", content = {
                            @Content(mediaType = "application/json", schema = @Schema(implementation = Map.class))
                    }),
                    @ApiResponse(responseCode = "500", description = "Failed to fetch account details")
            }
    )
    @GetMapping(value = "/account-details/{accountId}", produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseEntity<Map<String, String>> getAccountDetails(
            @PathVariable String accountNumber
    );

}