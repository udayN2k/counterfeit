package counterfeit_common.counterfeit_common.datasource.clients;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import counterfeit_common.counterfeit_common.datasource.entities.FIREntity;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionEntity;
import counterfeit_common.counterfeit_common.common.helper.DynamoDbHelper;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionReportingEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
@Slf4j
@Component
public class CounterfeitDynamoDbClient {

    private final AmazonDynamoDB amazonDynamoDB;

    private static final String TRANSACTION_TABLE_NAME = "Transaction";

    private static final String TRANSACTION_REPORTING_TABLE_NAME = "TransactionReporting";
    private static final String FIR_TABLE_NAME = "FIRDetails";

    @Autowired
    public CounterfeitDynamoDbClient(AmazonDynamoDB amazonDynamoDB) {
        this.amazonDynamoDB = amazonDynamoDB;
    }


    public void saveTransactions(TransactionEntity transaction) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_TABLE_NAME);

            dynamoDBMapper.save(transaction);

            log.info("All transactions saved successfully.");
        } catch (Exception e) {
            log.error("Failed to save transactions to DynamoDB: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to save transactions to DynamoDB", e);
        }
    }

    public void saveTransactionReporting(TransactionReportingEntity transactionReportingEntity) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_REPORTING_TABLE_NAME);

            dynamoDBMapper.save(transactionReportingEntity);

            log.info("All transactionReporting saved successfully.");
        } catch (Exception e) {
            log.error("Failed to save transactionReporting to DynamoDB: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to save transactionReporting to DynamoDB", e);
        }
    }

    public TransactionEntity findTransactionByHashKey(String recordId, Integer version) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_TABLE_NAME);
            return dynamoDBMapper.load(TransactionEntity.class, recordId, version);
        } catch (Exception e) {
            throw new RuntimeException("Failed to find transaction by hash key", e);
        }
    }

    public TransactionReportingEntity findTransactionReportingByHashKey(String transactionId) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_REPORTING_TABLE_NAME);
            return dynamoDBMapper.load(TransactionReportingEntity.class, transactionId);
        } catch (Exception e) {
            throw new RuntimeException("Failed to find transaction by hash key", e);
        }
    }
    public List<TransactionEntity> findAllTransactions() {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_TABLE_NAME);
            return dynamoDBMapper.scan(TransactionEntity.class, new DynamoDBScanExpression());
        } catch (Exception e) {
            throw new RuntimeException("Failed to retrieve all transactions from DynamoDB", e);
        }
    }

    public void updateTransaction(TransactionEntity transaction) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, TRANSACTION_TABLE_NAME);
            dynamoDBMapper.save(transaction);
            log.info("Transaction with Id{} saved successfully in DynamoDB.", transaction.getRecordId());
        } catch (Exception e) {
            log.error("Failed to save transaction with Id{} in DynamoDB: {}", transaction.getRecordId(), e.getMessage(), e );
            throw new RuntimeException("Failed to update transaction in DynamoDB", e);
        }
    }

    public void saveFir(FIREntity fir) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, FIR_TABLE_NAME);
            log.info("{}",dynamoDBMapper.batchSave(fir));
            dynamoDBMapper.batchSave(fir);
        } catch (Exception e) {
            throw new RuntimeException("Failed to save transactions to DynamoDB", e);
        }
    }

    public FIREntity findFIRByHashKey(String firReportId, String branchCode) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, FIR_TABLE_NAME);

            Map<String, AttributeValue> eav = new HashMap<>();
            eav.put(":branchCode", new AttributeValue().withS(branchCode));
            eav.put(":firReportId", new AttributeValue().withS(firReportId));

            DynamoDBQueryExpression<FIREntity> queryExpression = new DynamoDBQueryExpression<FIREntity>()
                    .withKeyConditionExpression("branchCode = :branchCode and firReportId = :firReportId")
                    .withExpressionAttributeValues(eav);

            List<FIREntity> result = dynamoDBMapper.query(FIREntity.class, queryExpression);

            return result.isEmpty() ? null : result.get(0);
        } catch (Exception e) {
            throw new RuntimeException("Failed to find FIR by hash key", e);
        }
    }

    public List<FIREntity> findByBranchCode(String branchCode) {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, FIR_TABLE_NAME);

            Map<String, AttributeValue> eav = new HashMap<>();
            eav.put(":branchCode", new AttributeValue().withS(branchCode));

            DynamoDBQueryExpression<FIREntity> queryExpression = new DynamoDBQueryExpression<FIREntity>()
                    .withKeyConditionExpression("branchCode = :branchCode ")
                    .withExpressionAttributeValues(eav);

            return dynamoDBMapper.query(FIREntity.class, queryExpression);
        } catch (Exception e) {
            throw new RuntimeException("Failed to find FIR by hash key", e);
        }
    }

    public List<FIREntity> findAllFIR() {
        try {
            DynamoDBMapper dynamoDBMapper = DynamoDbHelper.getDynamoDBMapper(amazonDynamoDB, FIR_TABLE_NAME);
            return dynamoDBMapper.scan(FIREntity.class, new DynamoDBScanExpression());
        } catch (Exception e) {
            throw new RuntimeException("Failed to retrieve all FIRs from DynamoDB", e);
        }
    }

}
