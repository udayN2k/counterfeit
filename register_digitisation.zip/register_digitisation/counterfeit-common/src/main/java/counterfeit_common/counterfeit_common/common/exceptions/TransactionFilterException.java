package counterfeit_common.counterfeit_common.common.exceptions;

public class TransactionFilterException extends Exception {
    public TransactionFilterException(String message) {
        super(message);
    }

    public TransactionFilterException(String message, Throwable cause) {
        super(message, cause);
    }
}