package counterfeit_common.counterfeit_common.common.helper;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import lombok.NonNull;

public class DynamoDbHelper {
  public static DynamoDBMapper getDynamoDBMapper(
      @NonNull AmazonDynamoDB amazonDynamoDB, @NonNull String tableName) {
    DynamoDBMapperConfig mapperConfig =
        DynamoDBMapperConfig.builder()
            .withTableNameOverride(new DynamoDBMapperConfig.TableNameOverride(tableName))
            .withBatchLoadRetryStrategy(DynamoDBMapperConfig.DEFAULT.getBatchLoadRetryStrategy())
            .withPaginationLoadingStrategy(
                DynamoDBMapperConfig.DEFAULT.getPaginationLoadingStrategy())
            .withBatchLoadRetryStrategy(DynamoDBMapperConfig.DEFAULT.getBatchLoadRetryStrategy())
            .withConsistentReads(DynamoDBMapperConfig.DEFAULT.getConsistentReads())
            .withBatchWriteRetryStrategy(DynamoDBMapperConfig.DEFAULT.getBatchWriteRetryStrategy())
            .withConversionSchema(DynamoDBMapperConfig.DEFAULT.getConversionSchema())
            .withBatchWriteRetryStrategy(DynamoDBMapperConfig.DEFAULT.getBatchWriteRetryStrategy())
            .withSaveBehavior(DynamoDBMapperConfig.SaveBehavior.UPDATE)
            .build();
    return new DynamoDBMapper(amazonDynamoDB, mapperConfig);
  }
}
