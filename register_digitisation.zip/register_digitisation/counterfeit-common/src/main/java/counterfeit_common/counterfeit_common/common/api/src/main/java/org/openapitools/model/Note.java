package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.Date;
import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class Note {

    private String noteId;

    private Integer slNo;

    @NotNull
    private String serialNumber;

    @NotNull
    private Integer denomination;

    @NotNull
    private String denominationType;

    @NotNull
    private List<String> securityFeatureBreached;

    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
    private Date policeReportingDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
    private Date returnFromPoliceDate;

    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
    private Date rbiSubmissionDate;

}