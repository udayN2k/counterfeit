package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestCount {
    private int firCount;
    private int noteCount;
}
