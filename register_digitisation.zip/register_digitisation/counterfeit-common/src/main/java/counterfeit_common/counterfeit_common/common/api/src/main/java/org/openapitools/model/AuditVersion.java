package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.Valid;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuditVersion {

    @Valid
    @Schema(name = "olderVersion", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("olderVersion")
    private List<Audit> olderVersion;

    @Valid
    @Schema(name = "currentVersion", requiredMode = Schema.RequiredMode.NOT_REQUIRED)
    @JsonProperty("currentVersion")
    private List<Audit> currentVersion;

}