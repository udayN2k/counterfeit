package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {

  private String recordId;

  @NotNull
  private Integer version;

  private String accountNumber;

  private String customerName;

  private String customerNumber;

  private String customerAddress;

  private String vendorName;

  private LocalDateTime creationDate;

  @NotNull
  private String transactionType;

  private List<@Valid Note> note_details = new ArrayList<>();

  private List<@Valid Activity> maker = new ArrayList<>();

  private List<@Valid Activity> checker = new ArrayList<>();

  private List<@Valid Remarks> userRemarks = new ArrayList<>();

  private  String status;

  private Integer note_count;

  @NotNull
  @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
  private Date detectionDate;

  private String firNumber;

  @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
  private Date firDate;

  private String firPath;

  private String crmId;

  private String atmNumber;

  private AuditVersion auditTrail;

  private LocalDateTime checkerApprovalDate;

  private LocalDateTime checkerRejectedDate;

  private  Activity branchDetails;

  private LocalDateTime updatedTime;

  private String userType;

  private List<String> documents;

  private String registerType;

  private String userAction;

}