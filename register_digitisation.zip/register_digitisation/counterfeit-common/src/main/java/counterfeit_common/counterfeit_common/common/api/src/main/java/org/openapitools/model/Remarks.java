package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class Remarks {

    private LocalDateTime remarksTimeStamp;

    private String userId;

    private String userType;

    private String remarks;
}
