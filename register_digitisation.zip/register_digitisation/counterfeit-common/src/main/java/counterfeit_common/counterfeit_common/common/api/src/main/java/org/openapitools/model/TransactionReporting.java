package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TransactionReporting {

    private String transactionId;

    private String recordId;

    private String customerName;

    private String customerNumber;

    private String customerAddress;

    private  Activity branchDetails;

    private String register;

    private List<@Valid Activity> maker = new ArrayList<>(); //userId, name

    private List<@Valid Activity> checker = new ArrayList<>();

    private List<String> documents;

    private LocalDateTime creationDate;

    private String status;

    private LocalDateTime checkerVerificationDate;

    private List<@Valid Remarks> userRemarks = new ArrayList<>();

    private List<@Valid Note> note_details = new ArrayList<>();
}
