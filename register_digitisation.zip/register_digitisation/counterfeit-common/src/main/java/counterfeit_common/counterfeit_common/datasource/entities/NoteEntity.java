package counterfeit_common.counterfeit_common.datasource.entities;

import com.amazonaws.services.dynamodbv2.datamodeling.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

@Data
public class NoteEntity {

    @DynamoDBHashKey
    private String noteId;

    @DynamoDBRangeKey
    private Integer sl_no;

    @DynamoDBAttribute
    private String serialNumber;

    @DynamoDBAttribute
    private Integer denomination;

    @DynamoDBAttribute
    private String denominationType;

    @DynamoDBAttribute
    private String securityFeatureBreached;

    private Date policeReportingDate;

    private Date returnFromPoliceDate;

    private Date rbiSubmissionDate;


}
