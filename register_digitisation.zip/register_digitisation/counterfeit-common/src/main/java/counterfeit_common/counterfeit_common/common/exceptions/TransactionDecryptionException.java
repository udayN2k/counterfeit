package counterfeit_common.counterfeit_common.common.exceptions;

public class TransactionDecryptionException extends Exception {
    public TransactionDecryptionException(String message) {
        super(message);
    }

    public TransactionDecryptionException(String message, Throwable cause) {
        super(message, cause);
    }
}