package counterfeit_common.counterfeit_common.datasource.impl;


import counterfeit_common.counterfeit_common.datasource.entities.FIREntity;

import java.util.List;

public interface FirDao {

    void saveFir(FIREntity fir);

    FIREntity findFIRByHashKey(String transactionId,String branchCode);

    List<FIREntity> findByBranchCode(String branchCode);

    List<FIREntity> getAllFIR();

}