package counterfeit_common.counterfeit_common.common.exceptions;

public class InvocationTargetException extends Exception {
    private static final long serialVersionUID = 4994602044371794741L;

    private Throwable targetException;

    public InvocationTargetException(Throwable target) {
        super(target == null ? null : target.toString());
        this.targetException = target;
    }

    public InvocationTargetException(Throwable target, String message) {
        super(message);
        this.targetException = target;
    }

    public Throwable getTargetException() {
        return targetException;
    }
}