    package counterfeit_common.counterfeit_common.datasource.entities;

    import com.amazonaws.services.dynamodbv2.datamodeling.*;
    import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.Transaction;
    import lombok.AllArgsConstructor;
    import lombok.Data;
    import lombok.NoArgsConstructor;

    import java.util.Map;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @DynamoDBTable(tableName = "BranchRegister")
    public class TransactionEntity {

        @DynamoDBHashKey
        private String recordId;

        @DynamoDBRangeKey
        private Integer version;

        @DynamoDBTypeConvertedJson
        private Map<String, Transaction> transactionData;
    }
