package counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FIR {
    private String firReportId;
    private String branchCode;
    private String remarks;

    private LocalDateTime postDate;
    private String month;
    private List<Activity> checker;
    private List<RequestCount> pendingWithPoliceBegining = new ArrayList<>();
    private List<RequestCount> sendToPolice = new ArrayList<>();
    private List<RequestCount> returnByPolice = new ArrayList<>();
    private List<RequestCount> pendingWithPoliceEnd = new ArrayList<>();

}
