package counterfeit_common.counterfeit_common.datasource.impl;

import counterfeit_common.counterfeit_common.datasource.entities.TransactionEntity;
import counterfeit_common.counterfeit_common.datasource.entities.TransactionReportingEntity;

import java.util.List;

public interface CounterfeitDao {

    TransactionEntity getTransactionById(String transactionId, Integer version);
    TransactionReportingEntity getTransactionReportingById(String transactionId);

    void saveTransaction(TransactionEntity transactions);
    void saveTransactionReporting(TransactionReportingEntity transactionReportingEntity);

    List<TransactionEntity> getAllTransactions();

    void updateTransaction(TransactionEntity transaction);

}