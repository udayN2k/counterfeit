package counterfeit_common.counterfeit_common.datasource.config;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.WebIdentityTokenCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;

public class DynamoDblocal {

    private static final String TRANSACTION = "Transaction";

    @Bean
    @Profile("!test")
    public AmazonDynamoDB amazonDynamoDB(final @Value("${dynamoDb.maxConnections}") int maxConnections) {
        return AmazonDynamoDBClientBuilder.standard()
                .withClientConfiguration(new ClientConfiguration().withMaxConnections(maxConnections))
                .withCredentials(WebIdentityTokenCredentialsProvider.create())
                .build();
    }

    @Bean(name = TRANSACTION)
    public DynamoDBMapper dynamoDBMapperTransactionInstruction(final AmazonDynamoDB amazonDynamoDB,
                                                               final @Value("${dynamoDb.transactionInstruction.tableName}") String tableName) {

        return new DynamoDBMapper(amazonDynamoDB, DynamoDBMapperConfig.builder()
                .withTableNameOverride(DynamoDBMapperConfig.TableNameOverride.withTableNameReplacement(tableName))
                .build());
    }
}
