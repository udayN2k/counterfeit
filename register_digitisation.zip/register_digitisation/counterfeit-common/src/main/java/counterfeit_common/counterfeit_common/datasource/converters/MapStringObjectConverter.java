package counterfeit_common.counterfeit_common.datasource.converters;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConverter;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

public class MapStringObjectConverter implements DynamoDBTypeConverter<String, Map<String, Object>> {
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public String convert(Map<String, Object> object) {
        try {
            return objectMapper.writeValueAsString(object);
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert map to JSON", e);
        }
    }

    @Override
    public Map<String, Object> unconvert(String objectString) {
        try {
            return objectMapper.readValue(objectString, Map.class);
        } catch (Exception e) {
            throw new RuntimeException("Failed to convert JSON to map", e);
        }
    }
}
