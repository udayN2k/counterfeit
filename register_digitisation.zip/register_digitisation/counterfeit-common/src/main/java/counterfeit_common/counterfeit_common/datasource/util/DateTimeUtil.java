package counterfeit_common.counterfeit_common.datasource.util;

        import java.time.LocalDateTime;
        import java.time.format.DateTimeFormatter;
        import java.util.Locale;

public class DateTimeUtil {
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a", Locale.ENGLISH);

    private DateTimeUtil() {
    }

    public static String format(LocalDateTime date) {
        if (date != null) {
            return date.format(DATE_TIME_FORMATTER).toUpperCase();
        }
        return null;
    }

    public static LocalDateTime parse(String dateStr) {
        if (dateStr != null && !dateStr.isEmpty()) {
            return LocalDateTime.parse(dateStr, DATE_TIME_FORMATTER);
        }
        return null;
    }
}