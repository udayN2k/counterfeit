package counterfeit_common.counterfeit_common.common.exceptions;

import counterfeit_common.counterfeit_common.common.helper.Problem;

import java.util.List;

public class ManagedException extends RuntimeException {

    private String errorMessage;
    private List<Problem> problems;

    private ManagedException(String message) {
        super(message);
        this.errorMessage = message;
    }

    private ManagedException(Throwable cause) {
        super(cause);
        this.errorMessage = cause.getMessage();
    }

    private ManagedException(String message, Throwable cause) {
        super(message, cause);
        this.errorMessage = message;
    }

    private ManagedException(String message, List<Problem> problems) {
        super(message);
        this.errorMessage = message;
        this.problems = problems;
    }

    public ManagedException(String unableToReadFileContent, Exception exception, String s) {
        super(unableToReadFileContent, exception);
        this.errorMessage = unableToReadFileContent;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public List<Problem> getProblems() {
        return problems;
    }

    public static class Builder {
        private String message;
        private Throwable cause;
        private List<Problem> problems;

        public Builder message(String message) {
            this.message = message;
            return this;
        }

        public Builder rawException(Throwable cause) {
            this.cause = cause;
            return this;
        }

        public Builder problems(List<Problem> problems) {
            this.problems = problems;
            return this;
        }

        public ManagedException build() {
            if (message != null && cause != null) {
                return new ManagedException(message, cause);
            } else if (message != null) {
                if (problems != null) {
                    return new ManagedException(message, problems);
                } else {
                    return new ManagedException(message);
                }
            } else if (cause != null) {
                return new ManagedException(cause);
            }
            throw new IllegalArgumentException("Either message or cause must be provided");
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}