package counterfeit_common.counterfeit_common.datasource.config;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.WebIdentityTokenCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapperConfig;
import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.Transaction;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class DynamoDBConfig {

    private static final String TRANSACTION = "Transaction";

    private static final String TRANSACTION_REPORTING = "TransactionReporting";

    private static final String FIR = "FirDetails";

    @Bean
    public AmazonDynamoDB amazonDynamoDB() {
        String accessKey = "mhdl3d";
        String secretKey = "k5edu";

        BasicAWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);

        return AmazonDynamoDBClientBuilder.standard()
                .withEndpointConfiguration(
                        new AwsClientBuilder.EndpointConfiguration("http://localhost:8000", "us-west-2")
                )
                .withCredentials(new AWSStaticCredentialsProvider(awsCredentials))
                .build();
    }


}