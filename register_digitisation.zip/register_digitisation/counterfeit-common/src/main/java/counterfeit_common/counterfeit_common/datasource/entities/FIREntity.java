package counterfeit_common.counterfeit_common.datasource.entities;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBRangeKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTypeConvertedJson;
import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.FIR;
import lombok.*;

import java.util.Map;

@Data
@DynamoDBTable(tableName = "FIRDetails")
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
public class FIREntity {

    @DynamoDBRangeKey
    private String firReportId;

    @DynamoDBHashKey
    private String branchCode;

    @DynamoDBTypeConvertedJson
    private Map<String,FIR> firData;


}