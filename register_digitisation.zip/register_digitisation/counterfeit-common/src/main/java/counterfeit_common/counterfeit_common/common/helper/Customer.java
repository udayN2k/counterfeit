package counterfeit_common.counterfeit_common.common.helper;

import lombok.AllArgsConstructor;
import org.simpleframework.xml.Element;
import org.simpleframework.xml.Root;

@AllArgsConstructor
@Root
public class Customer {

    @Element
    private String name;

    @Element
    private String addressLine1;

    @Element
    private String addressLine2;

    @Element
    private String phoneNumber;

}