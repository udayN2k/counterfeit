package counterfeit_common.counterfeit_common.common.exceptions;

public class TransactionNotFoundException extends RuntimeException{
    private final String message;
    public TransactionNotFoundException(String message) {

        super(message);
        this.message = message;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
