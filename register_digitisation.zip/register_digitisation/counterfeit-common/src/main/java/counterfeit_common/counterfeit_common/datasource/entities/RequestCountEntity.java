package counterfeit_common.counterfeit_common.datasource.entities;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBDocument;
import lombok.Data;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;

@Data

public class RequestCountEntity {

    @DynamoDBAttribute(attributeName = "FIR Count")
    private int firCount;

    @DynamoDBAttribute(attributeName = "Note Count")
    private int noteCount;


}
