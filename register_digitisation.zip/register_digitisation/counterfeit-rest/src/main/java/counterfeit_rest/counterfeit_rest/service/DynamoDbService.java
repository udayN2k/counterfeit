package counterfeit_rest.counterfeit_rest.service;

import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.*;

import java.net.URI;

@Slf4j
public class DynamoDbService {

    public static void createTransactionTable(DynamoDbClient ddbClient, String tableName) {

        CreateTableRequest createTableRequest = CreateTableRequest.builder()
                .tableName(tableName)
                .keySchema(
                        KeySchemaElement.builder()
                                .attributeName("requestId")
                                .keyType(KeyType.HASH)
                                .build()
                )
                .attributeDefinitions(
                        AttributeDefinition.builder()
                                .attributeName("requestId")
                                .attributeType(ScalarAttributeType.S)
                                .build()
                )
                .provisionedThroughput(
                        ProvisionedThroughput.builder()
                                .readCapacityUnits(5L)
                                .writeCapacityUnits(5L)
                                .build()
                )
                .build();

        try {
            CreateTableResponse response = ddbClient.createTable(createTableRequest);
           log.info("Table created successfully: " + response.tableDescription().tableName());
        } catch (DynamoDbException e) {
            log.error("Error creating table: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        DynamoDbClient ddbClient = DynamoDbClient.builder()
                .region(Region.US_WEST_2)
                .endpointOverride(URI.create("http://localhost:8001"))
                .credentialsProvider(StaticCredentialsProvider.create(AwsBasicCredentials.create("dummyKey", "dummySecret")))
                .build();

        String tableName = "Transaction2";

        createTransactionTable(ddbClient, tableName);
    }
}