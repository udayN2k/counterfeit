package counterfeit_rest.counterfeit_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Import;

@SpringBootApplication(scanBasePackages = {"counterfeit_common", "counterfeit_rest"})
@EnableFeignClients
@Import(org.springframework.cloud.openfeign.FeignAutoConfiguration.class)
public class CounterfeitRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CounterfeitRestApplication.class, args);
	}
}

