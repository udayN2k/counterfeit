package counterfeit_rest.counterfeit_rest.controller;

import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.api.TransactionsApi;
import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.FIR;
import counterfeit_common.counterfeit_common.common.api.src.main.java.org.openapitools.model.Transaction;
import counterfeit_rest.counterfeit_rest.service.ApiService;
import counterfeit_rest.counterfeit_rest.service.CounterfeitService;
import counterfeit_rest.counterfeit_rest.service.FIRService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Slf4j
@CrossOrigin(origins= {"http://localhost:5173"})
@RestController
@RequestMapping("/api/transactions")
public class CounterfeitController implements TransactionsApi {

    private final CounterfeitService counterfeitService;
    private final FIRService firService;
    private final ApiService apiService;
    private static final String ERROR_MESSAGE = "error";
    private static final String MESSAGE = "FIR fetched successfully: {}";

    @Autowired
    public CounterfeitController(CounterfeitService counterfeitService, FIRService firService,ApiService apiService) {
        this.counterfeitService = counterfeitService;
        this.firService = firService;
        this.apiService=apiService;
    }

    @Override
    public ResponseEntity<Map<String, Object>> createTransaction(
            @RequestBody Transaction transaction,
            @RequestParam String makerId,
            @RequestParam String branchCode,
            @RequestParam String makerName) {
        try {
            log.info("Creating transaction: ");

            ResponseEntity<Map<String, Object>> response = counterfeitService.createTransaction(transaction, makerId, makerName, branchCode);

            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("Transaction created successfully: {}", response.getBody());
            } else {
                log.warn("Transaction creation failed with status: {}", response.getStatusCode());
            }
            return response;

        } catch (Exception e) {
            log.error("Failed to create transaction: {}", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(ERROR_MESSAGE, "Failed to create transaction"));
        }
    }

    @Override
    public ResponseEntity<Transaction> getTransactionById(@PathVariable String recordId,@PathVariable Integer version) {
        try {
            log.info("Fetching transaction with ID: {}", recordId);
            ResponseEntity<Transaction> response = counterfeitService.getTransactionById(recordId, version);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("Transaction not found for ID: {}", recordId);
            } else {
                log.info("Transaction fetched successfully");
            }
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch transaction with ID: {}", recordId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<List<Transaction>> getTransactionsWithFilters(
            @RequestParam(value = "status", required = false) List<String> status,
            @RequestParam(value = "denominations", required = false) List<Integer> denominations,
            @RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date fromDate,
            @RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date toDate) {

        try {
            log.info("Fetching transactions with filters - status: {}, denominations: {}, fromDate: {}, toDate: {}",
                    status, denominations, fromDate, toDate);
              ResponseEntity<List<Transaction>> response = counterfeitService.getTransactionsWithFilters(status, denominations, fromDate, toDate);
            log.info("Successfully fetched {} transactions with the applied filters", response.getBody() != null ? response.getBody().size() : 0);
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch transactions with filters - status: {}, denominations: {}, fromDate: {}, toDate: {}",
                    status, denominations, fromDate, toDate, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<List<Transaction>> getAllTransactions() {
        try {
            log.info("Fetching all transactions");

            return counterfeitService.getAllTransactions();
        } catch (Exception e) {
            log.error("Failed to fetch all transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @Override
    public ResponseEntity<List<Transaction>> getTransactionsByMaker(
            @RequestParam String makerID) {
        try {
            log.info("Fetching transactions for makerID: {}", makerID);

            ResponseEntity<List<Transaction>> response = counterfeitService.getTransactionsByMaker(makerID);

            log.info("Successfully fetched transactions for the maker: {}", makerID);
            return response;
        } catch (Exception e) {
            log.error("Error occurred while fetching transactions for the maker", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @Override
    public ResponseEntity<List<Transaction>> getTransactionsByBranch(
            @RequestParam String branchCode) {
        try {
            log.info("Fetching transactions for branchCode: {}", branchCode);

            ResponseEntity<List<Transaction>> transactions = counterfeitService.getTransactionsByBranch(branchCode);

            log.info("Fetched transactions for branchCode: {}", branchCode);
            return transactions;
        } catch (Exception e) {
            log.error("Error fetching transactions for branchCode: {}", branchCode, e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> approveTransaction(
            @PathVariable String requestId,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @RequestBody Transaction updatedTransaction)
    {
        try {

            return counterfeitService.approveTransaction(requestId, checkerId, checkerName, updatedTransaction);
        } catch (Exception e) {
            log.error("Failed to approve transaction with ID: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(ERROR_MESSAGE, "Failed to approve transaction"));
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> addPoliceReportingDetails(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @RequestBody  Transaction transaction) {
        return counterfeitService.addPoliceReportingDetails(requestId, version, makerId, makerName, transaction);
    }

    @Override
    public ResponseEntity<Map<String, Object>> rejectTransaction(
            @PathVariable String requestId,
            @PathVariable Integer version,
            @RequestParam String remarks,
            @RequestParam String checkerId,
            @RequestParam String checkerName){

        try {
            log.info("Rejecting transaction with ID: {}", requestId);
            ResponseEntity<Map<String, Object>> response = counterfeitService.rejectTransaction(requestId, version, remarks, checkerId, checkerName);
            log.info("Transaction rejected successfully: {}", response.getBody());
            return response;
        } catch (Exception e) {
            log.error("Failed to reject transaction with ID: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(ERROR_MESSAGE, "Failed to reject transaction"));
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> updateTransaction(
            @PathVariable String requestId,
            @RequestParam String makerId,
            @RequestParam String makerName,
            @RequestBody Transaction transaction) {
        try {
            log.info("Updating transaction with ID: {}", requestId);
            ResponseEntity<Map<String, Object>> response = counterfeitService.updateTransaction(requestId, makerId, makerName, transaction);
            log.info("Transaction updated successfully: {}", response.getBody());
            return response;
        } catch (Exception e) {
            log.error("Failed to update transaction with ID: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of(ERROR_MESSAGE, "Failed to update transaction"));
        }
    }

    @Override
    public ResponseEntity<byte[]> getPdfAsBytes(@PathVariable String requestId,
                                                @RequestParam String copyType) {
        try {
            byte[] pdfBytes = counterfeitService.readPdfAsBytes(requestId, copyType);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("attachment", requestId + ".pdf");

            return ResponseEntity.ok()
                    .headers(headers)
                    .body(pdfBytes);
        } catch (FileNotFoundException e) {
            log.error("PDF file not found for requestId: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        } catch (IOException e) {
            log.error("Error reading PDF file for requestId: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public ResponseEntity<Map<String, Object>> createFIR(
            @RequestBody FIR fir,
            @RequestParam String checkerId,
            @RequestParam String checkerName,
            @RequestParam String branchCode) {

        try {
            log.info("Creating FIR: {}", fir);
            ResponseEntity<Map<String, Object>> response = firService.createFir(fir, checkerId, checkerName, branchCode);
            if (response.getStatusCode().is2xxSuccessful()) {
                log.info("FIR created successfully: {}", response.getBody());
            } else {
                log.warn("FIR creation failed with status: {}", response.getStatusCode());
            }
            return response;

        } catch (Exception e) {
            log.error("Failed to create FIR: {}", fir, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of(ERROR_MESSAGE, "Failed to create FIR"));
        }
    }

    @Override
    public ResponseEntity<FIR> getFIRById(@PathVariable String requestId, @PathVariable String branchCode) {
        try {
            log.info("Fetching FIR with ID: {}", requestId);
            ResponseEntity<FIR> response = firService.getFIRById(requestId, branchCode);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("FIR not found for ID: {}", requestId);
            } else {
                log.info(MESSAGE, response.getBody());
            }
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch FIR with ID: {}", requestId, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<List<FIR>> findByBranchCode(@PathVariable String branchCode) {
        try {
            log.info("Fetching FIR with branchCode: {}", branchCode);
            ResponseEntity<List<FIR>> response = firService.findByBranchCode(branchCode);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("FIR not found for branchCode: {}", branchCode);
            } else {
                log.info(MESSAGE, response.getBody());
            }
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch FIR with branchCode: {}", branchCode, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @Override
    public ResponseEntity<List<FIR>> getLastMonthFIRs(@PathVariable String branchCode) {
        try {
            log.info("Fetching FIR with branchCode: {}", branchCode);
            ResponseEntity<List<FIR>> response = firService.getLastMonthFIRs(branchCode);
            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("FIR not found for branchCode: {}", branchCode);
            } else {
                log.info(MESSAGE, response.getBody());
            }
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch FIR with branchCode: {}", branchCode, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<List<Integer>> getTotalFIRPerMonth(String branchCode) {
        try {
            log.info("Fetching all transactions");
            ResponseEntity<List<Integer>> response = counterfeitService.getTotalFIRPerMonth(branchCode);
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch all transactions", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<List<FIR>> getFilters(
            @RequestParam(value = "fromDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date fromDate,
            @RequestParam(value = "toDate", required = false) @DateTimeFormat(pattern = "dd/MM/yyyy") Date toDate) {
        try {
            log.info("Fetching FIR with fromDate: {} and toDate: {}", fromDate, toDate);

            ResponseEntity<List<FIR>> response = firService.getFilters(fromDate, toDate);

            if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
                log.warn("FIR not found for the given date range: fromDate: {}, toDate: {}", fromDate, toDate);
            } else {
                log.info("FIR fetched successfully: {}", response.getBody());
            }
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch FIR with fromDate: {} and toDate: {}", fromDate, toDate, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Override
    public ResponseEntity<Map<String, String>> getAccountDetails(@PathVariable String accountId) {
        log.info("Fetching account details for accountId: {}", accountId);

        Map<String, String> accountDetails = apiService.fetchAccountDetails(accountId);

        if (accountDetails == null) {
            log.warn("Account details not found for accountId: {}", accountId);
            return ResponseEntity.notFound().build();
        }

        log.info("Successfully fetched account details for accountId: {}", accountId);
        return ResponseEntity.ok(accountDetails);
    }


    @Override
    public ResponseEntity<List<FIR>> getAllFIR() {
        try {
            log.info("Fetching all FIRs");
            ResponseEntity<List<FIR>> response = firService.getAllFIR();
            log.info("Fetched {} FIRs", response.getBody().size());
            return response;
        } catch (Exception e) {
            log.error("Failed to fetch all FIRs", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}