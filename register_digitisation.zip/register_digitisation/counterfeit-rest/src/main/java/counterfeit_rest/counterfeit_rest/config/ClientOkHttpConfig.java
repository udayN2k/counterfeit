package counterfeit_rest.counterfeit_rest.config;

import counterfeit_rest.counterfeit_rest.service.CrnApiClient;
import counterfeit_rest.counterfeit_rest.service.FinacleApiClient;
import feign.Feign;
import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

@Configuration
public class ClientOkHttpConfig {

    private final String finacleHost;
    private final String crnHost;

    public ClientOkHttpConfig(@Value("${finacle.service.host}") String finacleHost, @Value("${crn.server.host}") String crnHost){
        this.finacleHost = finacleHost;
        this.crnHost = crnHost;
    }
    X509TrustManager trustManager =
            new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() {
                    return new X509Certificate[0];
                }

                public void checkClientTrusted(X509Certificate[] certs, String authType) {
                }

                public void checkServerTrusted(X509Certificate[] certs, String authType) {
                }
            };

    @Bean
    public OkHttpClient getClient() throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sslContext;
        try {
            sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, new X509TrustManager[]{trustManager}, new SecureRandom());
        } catch (Exception exception) {

            throw exception;

        }
        return new OkHttpClient.Builder()
                .sslSocketFactory(sslContext.getSocketFactory(), trustManager)
                .hostnameVerifier((hostname, session) -> true)
                .build();
    }

    @Bean
    public FinacleApiClient getFinacleApiClient() throws NoSuchAlgorithmException, KeyManagementException {
        return Feign.builder()
                .client(new feign.okhttp.OkHttpClient(getClient()))
                .target(FinacleApiClient.class, finacleHost);
    }

    @Bean
    public CrnApiClient getCrnApiClient() throws NoSuchAlgorithmException, KeyManagementException {
        return Feign.builder()
                .client(new feign.okhttp.OkHttpClient(getClient()))
                .target(CrnApiClient.class, crnHost);
    }



}
