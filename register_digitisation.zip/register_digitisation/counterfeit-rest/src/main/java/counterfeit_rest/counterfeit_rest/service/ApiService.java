package counterfeit_rest.counterfeit_rest.service;

import feign.FeignException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import java.io.StringReader;
import java.util.HashMap;
import java.util.Map;

@Service
public class ApiService {

    private static final Logger logger = LoggerFactory.getLogger(ApiService.class);

    private final FinacleApiClient finacleApiClient;
    private final CrnApiClient crnApiClient;
    private final XmlRequestBuilder xmlRequestBuilder;

    public ApiService(FinacleApiClient finacleApiClient, CrnApiClient crnApiClient) {
        this.finacleApiClient = finacleApiClient;
        this.crnApiClient = crnApiClient;
        this.xmlRequestBuilder = new XmlRequestBuilder();
    }

    public Map<String, String> fetchAccountDetails(String accountId) {
        String xmlRequest = xmlRequestBuilder.buildRequest(accountId);
        try {
            String response = finacleApiClient.finacleRestCall(xmlRequest);
            Map<String, String> accountDetails = parseResponse(response);

            if (accountDetails != null) {
                String crn = accountDetails.get("crn");
                Map<String, String> contactDetails = fetchContactNumber(crn);
                if (contactDetails != null) {
                    accountDetails.put("contactNumber", contactDetails.get("contactNumber"));
                }
            }

            return accountDetails;
        } catch (FeignException fe) {
            logger.error("Error fetching account details: {}", fe.getMessage());
        }
        return null;
    }

    private Map<String, String> parseResponse(String xml) {
        Map<String, String> accountDetails = new HashMap<>();
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            doc.getDocumentElement().normalize();

            Node generalDetailsNode = doc.getElementsByTagName("GeneralDetails").item(0);
            if (generalDetailsNode != null && generalDetailsNode.getNodeType() == Node.ELEMENT_NODE) {
                Element generalDetailsElement = (Element) generalDetailsNode;
                accountDetails.put("accountNumber", getElementValue(generalDetailsElement, "Acid"));
                accountDetails.put("customerName", getElementValue(generalDetailsElement, "AcctName"));
                accountDetails.put("crn", getElementValue(generalDetailsElement, "CIFId"));
                NodeList acctBranchInfoNodes = generalDetailsElement.getElementsByTagName("AcctBranchInfo");
                if (acctBranchInfoNodes.getLength() > 0) {
                    Node acctBranchInfoNode = acctBranchInfoNodes.item(0);
                    accountDetails.put("SolId", getElementValue(acctBranchInfoNode, "SolId"));
                } else {
                    accountDetails.put("SolId", null);
                }

                Node addrNode = generalDetailsElement.getElementsByTagName("AddrDtls").item(0);
                if (addrNode != null && addrNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element addrElement = (Element) addrNode;
                    StringBuilder address = new StringBuilder()
                            .append(getElementValue(addrElement, "AddrLine1"))
                            .append(getElementValue(addrElement, "AddrLine2"))
                            .append(getElementValue(addrElement,"AddrLine3"))
                            .append(getElementValue(addrElement, "City"))
                            .append(getElementValue(addrElement, "State"))
                            .append(getElementValue(addrElement, "Country"))
                            .append(getElementValue(addrElement, "ZipCode"));
                    accountDetails.put("address", address.toString());
                }
            }
        } catch (Exception e) {
            logger.error("Error parsing response: {}", e.getMessage(), e);
        }
        return accountDetails;
    }

    public Map<String, String> fetchContactNumber(String crn) {
        String xmlRequest = xmlRequestBuilder.buildCrnRequest(crn);
        logger.info("Request from CRN API: {}", xmlRequest);
        try {
            String response = crnApiClient.crnRestCall(xmlRequest);
            logger.info("Response from CRN API: {}", response);

            if (response == null) {
                logger.warn("No response received for CRN: {}", crn);
                return null;
            }
            return parseCrnDetailsResponse(response);
        } catch (FeignException fe) {
            logger.error("Error fetching contact number for CRN {}: {}", crn, fe.getMessage());
        }
        return null;
    }

    private Map<String, String> parseCrnDetailsResponse(String xml) {
        Map<String, String> contactDetails = new HashMap<>();
        try {
            Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            doc.getDocumentElement().normalize();

            NodeList contactDetailsNodes = doc.getElementsByTagName("contact_details");
            if (contactDetailsNodes.getLength() > 0) {
                Node contactDetailsNode = contactDetailsNodes.item(0);
                String phone1 = getElementValue(contactDetailsNode, "pref_mobile");
                contactDetails.put("contactNumber", phone1);
            }
        } catch (Exception e) {
            logger.error("Error parsing CRN details response: {}", e.getMessage(), e);
        }
        return contactDetails;
    }

    private String getElementValue(Node parentNode, String tagName) {
        NodeList nodeList = parentNode.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeName().equals(tagName)) {
                return node.getTextContent();
            }
        }
        return null;
    }


}