package counterfeit_rest.counterfeit_rest.service;

import feign.Headers;
import feign.RequestLine;

public interface CrnApiClient {

    @RequestLine("POST")
    @Headers("Content-Type: application/xml")
    String crnRestCall(String requestBody);
}